from dataclasses import dataclass
from dataclasses import field, asdict
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


@dataclass
class DomainDefinition:
    """
    User-created domain definition.

    Examples:
        >>> my_domain = DomainDefinition(
        ...     name="nutrition",
        ...     display_name="التغذية والصحة",
        ...     language="ar",
        ...     terms=["بروتين", "كربوهيدرات", "فيتامين", "سعرات", "حمية"],
        ...     synonyms={"سعرات": ["كالوري", "طاقة"], "حمية": ["رجيم", "دايت"]},
        ...     system_prompt="أنت خبير تغذية. أجب بدقة علمية وأضف تحذيرات عند الضرورة.",
        ...     rejection_message="هذا السؤال خارج نطاق التغذية والصحة.",
        ...     min_relevance=0.15,
        ... )
    """

    # الحقول الإلزامية | Required fields
    name: str                          # معرف المجال  e.g. "nutrition"
    terms: List[str]                   # مصطلحات المجال الأساسية

    # الحقول الاختيارية | Optional fields
    display_name: str = ""             # اسم عرض جميل  e.g. "التغذية والصحة"
    language: str = "ar"              # لغة المصطلحات
    synonyms: Dict[str, List[str]] = field(default_factory=dict)
    # مرادفات: {"سعرات": ["كالوري", "طاقة"]}

    system_prompt: str = ""
    # تعليمات خاصة للنموذج عند الإجابة في هذا المجال

    rejection_message: str = ""
    # رسالة الرفض عند استخدام strict_mode

    min_relevance: float = 0.10
    # حد الصلة الأدنى (0.0 → 1.0)

    boost_weight: float = 1.5
    # وزن تعزيز المصطلحات عند ترتيب النتائج

    metadata: Dict[str, Any] = field(default_factory=dict)
    # بيانات إضافية حرة يضيفها المستخدم

    # ── توليد داخلي ──────────────────────────
    def __post_init__(self):
        if not self.display_name:
            self.display_name = self.name
        if not self.rejection_message:
            self.rejection_message = (
                f"your quesion is out of zone for this domain'{self.display_name}'."
            )
        self._all_terms: Optional[Set[str]] = None

    @property
    def all_terms(self) -> Set[str]:
        """
          all terms + synonyms in a single set
        """
        if self._all_terms is None:
            expanded: Set[str] = set(t.lower() for t in self.terms)
            for syns in self.synonyms.values():
                expanded.update(s.lower() for s in syns)
            self._all_terms = expanded
        return self._all_terms

    def add_terms(self, *terms: str):
        """
            add a new set of terms
       
        """
        for t in terms:
            t = t.strip()
            if t and t not in self.terms:
                self.terms.append(t)
        self._all_terms = None  # إعادة بناء الـ cache

    def add_synonym(self, term: str, *synonyms: str):
        """
            add synonyms to a term 
        """
        self.synonyms.setdefault(term, []).extend(
            s for s in synonyms if s not in self.synonyms.get(term, [])
        )
        self._all_terms = None

    # ── تسلسل JSON ───────────────────────────
    def to_dict(self) -> Dict:
        d = asdict(self)
        d.pop("_all_terms", None)
        return d

    @classmethod
    def from_dict(cls, data: Dict) -> "DomainDefinition":
        data.pop("_all_terms", None)
        return cls(**data)

    def save(self, path: str):
        """حفظ المجال في ملف JSON
          save the domain to a JSON file
        """
        Path(path).write_text(
            json.dumps(self.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        logger.info("💾 Domain '%s' saved to %s", self.name, path)

    @classmethod
    def load(cls, path: str) -> "DomainDefinition":
        """
           load the domain from a JSON file
        """
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(data)


# ─────────────────────────────────────────────
#  مجالات جاهزة (اختيارية) — يمكن للمستخدم
#  تجاهلها تماماً أو تعديلها كنقطة انطلاق
# ─────────────────────────────────────────────
PRESET_DOMAINS: Dict[str, DomainDefinition] = {
    "medical": DomainDefinition(
        name="medical",
        display_name="الطب والصحة",
        terms=["دواء", "علاج", "مرض", "أعراض", "تشخيص", "جرعة", "مريض", "طبيب"],
        synonyms={"دواء": ["عقار", "دواية"], "علاج": ["معالجة", "ثيرابي"]},
        system_prompt=(
            "أنت مساعد طبي متخصص. مهمتك الإجابة بناءً على المستند المرفق فقط.\n"
            "القواعد الصارمة:\n"
            "1. استخرج إجابتك حصرياً من نص المستند المرفق.\n"
            "2. إذا لم تجد المعلومة في المستند، قل: 'هذه المعلومة غير موجودة في المستند المرفق.'\n"
            "3. لا تضف أي معلومات طبية من معرفتك الخاصة.\n"
            "4. اذكر دائماً ضرورة استشارة طبيب مختص قبل أي قرار طبي.\n"
            "5. إذا كان السؤال يتعلق بجرعات أو أدوية، نبّه بوضوح على خطورة التطبيق الذاتي."
        ),
        rejection_message="سؤالك خارج نطاق الطب والصحة. يُرجى طرح أسئلة متعلقة بالمجال الطبي فقط.",
    ),

    "legal": DomainDefinition(
        name="legal",
        display_name="القانون والتشريع",
        terms=["قانون", "مادة", "حكم", "محكمة", "عقد", "دعوى", "تشريع", "حق"],
        system_prompt=(
            "أنت مستشار قانوني. مهمتك الإجابة بناءً على المستند المرفق فقط.\n"
            "القواعد الصارمة:\n"
            "1. استند حصرياً إلى نصوص ومواد المستند المرفق.\n"
            "2. إذا لم تجد نصاً قانونياً يغطي السؤال، قل: 'لا يوجد نص في المستند يُعالج هذه المسألة.'\n"
            "3. اذكر رقم المادة أو الفصل من المستند عند الاقتباس.\n"
            "4. نبّه دائماً أن هذه المعلومات لا تُغني عن استشارة محامٍ مرخص.\n"
            "5. لا تُفسّر أو تستنتج ما لم يُذكر صراحةً في المستند."
        ),
        rejection_message="سؤالك خارج نطاق القانون والتشريع. يُرجى طرح أسئلة قانونية فقط.",
    ),

    "technical": DomainDefinition(
        name="technical",
        display_name="التقنية والبرمجة",
        terms=["كود", "برمجة", "نظام", "تطبيق", "API", "خوارزمية", "قاعدة بيانات"],
        synonyms={"كود": ["شيفرة", "كودة", "سكريبت"]},
        system_prompt=(
            "أنت مساعد تقني متخصص. مهمتك الإجابة بناءً على المستند المرفق فقط.\n"
            "القواعد الصارمة:\n"
            "1. اعتمد على التوثيق والأكواد الموجودة في المستند المرفق فقط.\n"
            "2. إذا لم يغطِ المستند السؤال، قل: 'هذه التفاصيل غير موجودة في التوثيق المرفق.'\n"
            "3. عند اقتباس كود من المستند، اذكره كما هو دون تعديل.\n"
            "4. لا تقترح حلولاً تقنية من خارج المستند."
        ),
        rejection_message="سؤالك خارج نطاق التقنية والبرمجة. يُرجى طرح أسئلة تقنية فقط.",
    ),

    "financial": DomainDefinition(
        name="financial",
        display_name="المال والاستثمار",
        terms=["سهم", "استثمار", "بورصة", "تداول", "ربح", "خسارة", "عائد", "أصول"],
        system_prompt=(
            "أنت محلل مالي. مهمتك الإجابة بناءً على المستند المرفق فقط.\n"
            "القواعد الصارمة:\n"
            "1. استخرج الأرقام والبيانات المالية من المستند المرفق فقط.\n"
            "2. إذا لم تجد البيانات في المستند، قل: 'هذه البيانات غير متوفرة في المستند المرفق.'\n"
            "3. لا تتنبأ أو تستنتج أرقاماً غير موجودة في المستند.\n"
            "4. نبّه دائماً على مخاطر الاستثمار وأن المعلومات لا تُعدّ توصية مالية."
        ),
        rejection_message="سؤالك خارج نطاق المال والاستثمار. يُرجى طرح أسئلة مالية فقط.",
    ),

    "academic": DomainDefinition(
        name="academic",
        display_name="الأبحاث والأكاديميا",
        terms=["بحث", "دراسة", "نظرية", "تحليل", "منهجية", "فرضية", "إحصاء"],
        system_prompt=(
            "أنت مساعد أكاديمي متخصص. مهمتك الإجابة بناءً على المستند المرفق فقط.\n"
            "القواعد الصارمة:\n"
            "1. اعتمد حصرياً على محتوى المستند البحثي المرفق.\n"
            "2. إذا لم يتناول المستند السؤال، قل: 'هذا الجانب لم يتناوله البحث المرفق.'\n"
            "3. اذكر القسم أو الصفحة من المستند عند الاستشهاد.\n"
            "4. لا تدمج نتائج من أبحاث أخرى غير موجودة في المستند.\n"
            "5. فرّق بين ما هو نتيجة مباشرة وما هو استنتاج في إجابتك."
        ),
        rejection_message="سؤالك خارج نطاق الأبحاث والأكاديميا. يُرجى طرح أسئلة أكاديمية فقط.",
    ),
}