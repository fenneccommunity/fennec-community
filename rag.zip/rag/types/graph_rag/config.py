# -*- coding: utf-8 -*-
"""
Configuration module for GraphRAG system
Supports environment variables and validation
"""

from dataclasses import dataclass
from typing import Optional
import os
import logging

logger = logging.getLogger(__name__)


@dataclass
class ConfigGraphRAG:
    """
    Configuration class for GraphRAG system
    
    Attributes:
        l1_size: Level 1 cache size
        l2_size: Level 2 cache size
        l3_size: Level 3 cache size
        k: Number of top results to retrieve
        context_depth: Depth of context expansion in graph
        max_depth: Maximum depth for graph traversal
        embedder_name: Name of the sentence transformer model
        embedding_dim: Dimension of embeddings (auto-detected if None)
        batch_size: Batch size for embedding generation
        use_gpu: Whether to use GPU for FAISS operations
        faiss_nlist: Number of clusters for IVF index (auto-calculated if None)
        rebuild_threshold: Rebuild index after N additions
        cache_ttl: Cache time-to-live in seconds
        enable_hybrid_search: Enable hybrid semantic+keyword search
    """
    
    # Cache configuration
    l1_size: int = 50
    l2_size: int = 50
    l3_size: int = 50
    cache_ttl: int = 300
    
    # Retrieval configuration
    k: int = 5
    context_depth: int = 2
    max_depth: int = 2
    
    # Embedding configuration
    embedder_name: str = "paraphrase-multilingual-MiniLM-L12-v2"
    embedding_dim: Optional[int] = None
    batch_size: int = 32
    normalize_embeddings: bool = True
    
    # FAISS configuration
    use_gpu: bool = False
    faiss_nlist: Optional[int] = None
    faiss_nprobe: int = 10
    rebuild_threshold: int = 100
    
    # Search configuration
    enable_hybrid_search: bool = False
    hybrid_alpha: float = 0.5  # Weight for semantic vs keyword (0-1)
    
    # Performance
    max_cache_embeddings: int = 1000
    parallel_processing: bool = True
    
    # Logging
    log_level: str = "INFO"
    
    def __post_init__(self):
        """Validate configuration after initialization"""
        self._validate()
        self._setup_logging()
    
    def _validate(self):
        """Validate configuration parameters"""
        if self.k < 1:
            raise ValueError("k must be at least 1")
        
        if self.context_depth < 0:
            raise ValueError("context_depth cannot be negative")
        
        if self.max_depth < 0:
            raise ValueError("max_depth cannot be negative")
        
        if not 0 <= self.hybrid_alpha <= 1:
            raise ValueError("hybrid_alpha must be between 0 and 1")
        
        if self.batch_size < 1:
            raise ValueError("batch_size must be at least 1")
        
        logger.info("Configuration validated successfully")
    
    def _setup_logging(self):
        """Setup logging configuration"""
        logging.basicConfig(
            level=getattr(logging, self.log_level.upper()),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    @classmethod
    def from_env(cls) -> 'ConfigGraphRAG':
        """
        Create configuration from environment variables
        
        Environment variables:
            GRAPHRAG_K: Number of top results
            GRAPHRAG_EMBEDDER: Embedder model name
            GRAPHRAG_BATCH_SIZE: Batch size for embeddings
            GRAPHRAG_USE_GPU: Use GPU (true/false)
            GRAPHRAG_LOG_LEVEL: Logging level
        
        Returns:
            ConfigGraphRAG instance with env variables applied
        """
        return cls(
            k=int(os.getenv('GRAPHRAG_K', 5)),
            context_depth=int(os.getenv('GRAPHRAG_CONTEXT_DEPTH', 2)),
            max_depth=int(os.getenv('GRAPHRAG_MAX_DEPTH', 2)),
            embedder_name=os.getenv('GRAPHRAG_EMBEDDER', 'all-MiniLM-L6-v2'),
            batch_size=int(os.getenv('GRAPHRAG_BATCH_SIZE', 32)),
            use_gpu=os.getenv('GRAPHRAG_USE_GPU', 'false').lower() == 'true',
            log_level=os.getenv('GRAPHRAG_LOG_LEVEL', 'INFO'),
            enable_hybrid_search=os.getenv('GRAPHRAG_HYBRID_SEARCH', 'false').lower() == 'true',
        )
    
    def to_dict(self) -> dict:
        """Convert configuration to dictionary"""
        return {
            'l1_size': self.l1_size,
            'l2_size': self.l2_size,
            'l3_size': self.l3_size,
            'k': self.k,
            'context_depth': self.context_depth,
            'max_depth': self.max_depth,
            'embedder_name': self.embedder_name,
            'batch_size': self.batch_size,
            'use_gpu': self.use_gpu,
        }


