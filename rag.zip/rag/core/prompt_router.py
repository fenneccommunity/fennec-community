"""
Prompt Router - Detects query language and type, then selects the most suitable prompt template
"""

from __future__ import annotations

import re
import logging
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# QuestionType  |  نوع السؤال
# ──────────────────────────────────────────────────────────────────────────────

class QuestionType(Enum):
    """
    Question type classifications
    """
    FACTUAL      = "factual"       # سؤال عن حقيقة / fact question
    ANALYTICAL   = "analytical"    # سؤال تحليلي   / analytical question
    COMPARATIVE  = "comparative"   # سؤال مقارن    / comparative question
    PROCEDURAL   = "procedural"    # سؤال إجرائي   / how-to / procedural
    DEFINITIONAL = "definitional"  # سؤال تعريفي   / definition question
    EVALUATIVE   = "evaluative"    # سؤال تقييمي   / evaluation question
    CAUSAL       = "causal"        # سؤال سببي     / cause-effect question
    GENERAL      = "general"       # عام / general fallback


# ──────────────────────────────────────────────────────────────────────────────
# Few-shot examples store  |  مخزن الأمثلة
# ──────────────────────────────────────────────────────────────────────────────

_FEW_SHOT_AR: dict[QuestionType, str] = {
    QuestionType.FACTUAL: (
        "مثال: السؤال: ما عاصمة المملكة العربية السعودية؟\n"
        "الإجابة: الرياض هي عاصمة المملكة العربية السعودية.\n\n"
    ),
    QuestionType.ANALYTICAL: (
        "مثال: السؤال: ما أسباب ارتفاع الأسعار؟\n"
        "الإجابة: ترتبط الأسباب الرئيسية بـ(أ) ارتفاع تكاليف الإنتاج، "
        "(ب) زيادة الطلب، (ج) اضطرابات سلاسل الإمداد.\n\n"
    ),
    QuestionType.COMPARATIVE: (
        "مثال: السؤال: ما الفرق بين الذكاء الاصطناعي والتعلم الآلي؟\n"
        "الإجابة: الذكاء الاصطناعي مجال أشمل، أما التعلم الآلي فهو فرع منه "
        "يركز على تدريب النماذج من البيانات.\n\n"
    ),
    QuestionType.PROCEDURAL: (
        "مثال: السؤال: كيف أنشئ مشروع Python؟\n"
        "الإجابة: الخطوات: (1) أنشئ مجلداً، (2) شغّل python -m venv venv، "
        "(3) فعّل البيئة، (4) أضف ملف requirements.txt.\n\n"
    ),
    QuestionType.DEFINITIONAL: (
        "مثال: السؤال: ما معنى RAG؟\n"
        "الإجابة: RAG اختصار Retrieval-Augmented Generation، وهو أسلوب يدمج "
        "البحث في قاعدة المعرفة مع توليد النصوص.\n\n"
    ),
    QuestionType.GENERAL: "",
}

_FEW_SHOT_EN: dict[QuestionType, str] = {
    QuestionType.FACTUAL: (
        "Example — Q: What is the capital of France?\n"
        "A: The capital of France is Paris.\n\n"
    ),
    QuestionType.ANALYTICAL: (
        "Example — Q: What are the main causes of inflation?\n"
        "A: The primary causes are (a) rising production costs, "
        "(b) increased demand, (c) supply-chain disruptions.\n\n"
    ),
    QuestionType.COMPARATIVE: (
        "Example — Q: What is the difference between AI and ML?\n"
        "A: AI is the broader field; ML is a subset focused on learning from data.\n\n"
    ),
    QuestionType.PROCEDURAL: (
        "Example — Q: How do I create a Python project?\n"
        "A: Steps: (1) create a directory, (2) run python -m venv venv, "
        "(3) activate it, (4) add requirements.txt.\n\n"
    ),
    QuestionType.DEFINITIONAL: (
        "Example — Q: What does RAG stand for?\n"
        "A: RAG stands for Retrieval-Augmented Generation, a technique that "
        "combines knowledge-base search with text generation.\n\n"
    ),
    QuestionType.GENERAL: "",
}


# ──────────────────────────────────────────────────────────────────────────────
# Keyword patterns  |  أنماط الكلمات المفتاحية
# ──────────────────────────────────────────────────────────────────────────────

_PATTERNS_AR: list[tuple[QuestionType, re.Pattern]] = [
    (QuestionType.COMPARATIVE,  re.compile(r"الفرق|مقارنة|أيهما|بين .+ و|vs|versus", re.I)),
    (QuestionType.PROCEDURAL,   re.compile(r"كيف|خطوات|طريقة|أنشئ|اصنع|اعمل|شرح طريقة", re.I)),
    (QuestionType.DEFINITIONAL, re.compile(r"ما هو|ما هي|ما معنى|عرّف|تعريف|اشرح معنى", re.I)),
    (QuestionType.ANALYTICAL,   re.compile(r"لماذا|أسباب|تحليل|وضّح|اشرح|ناقش|أثر", re.I)),
    (QuestionType.CAUSAL,       re.compile(r"سبب|نتيجة|أدى إلى|يؤثر|علاقة بين", re.I)),
    (QuestionType.EVALUATIVE,   re.compile(r"قيّم|هل يجب|هل من الأفضل|ما رأيك|ما أفضل", re.I)),
    (QuestionType.FACTUAL,      re.compile(r"من هو|متى|أين|كم|ما اسم|ما عدد", re.I)),
]

_PATTERNS_EN: list[tuple[QuestionType, re.Pattern]] = [
    (QuestionType.COMPARATIVE,  re.compile(r"\bvs\.?\b|versus|compare|difference between|which is better", re.I)),
    (QuestionType.PROCEDURAL,   re.compile(r"\bhow (to|do|can|should)\b|steps to|guide to|way to", re.I)),
    (QuestionType.DEFINITIONAL, re.compile(r"\bwhat (is|are|does)\b|define|definition|meaning of", re.I)),
    (QuestionType.ANALYTICAL,   re.compile(r"\bwhy\b|analyze|explain|discuss|causes of|effects of", re.I)),
    (QuestionType.CAUSAL,       re.compile(r"\bcause\b|leads? to|results? in|impact of|effect of", re.I)),
    (QuestionType.EVALUATIVE,   re.compile(r"\bshould\b|evaluate|is it better|what.*recommend|pros and cons", re.I)),
    (QuestionType.FACTUAL,      re.compile(r"\bwho\b|\bwhen\b|\bwhere\b|\bhow many\b|\bhow much\b|\bwhich\b", re.I)),
]

# Arabic Unicode range check
_ARABIC_RE = re.compile(r"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]")


# ──────────────────────────────────────────────────────────────────────────────
# PromptRouter
# ──────────────────────────────────────────────────────────────────────────────

class PromptRouter:
    """
    Routes each query to the most appropriate prompt template
    Main responsibilities:
    ─────────────────────────────────────────
    • detect_language(query)        → 'ar' | 'en'
    • detect_question_type(query)   → QuestionType
    • build(query, context, language) → prompt str
    """

    def __init__(self, include_few_shot: bool = True):
        """
        Args:
            include_few_shot:  Include few-shot examples
        """
        self.include_few_shot = include_few_shot
        logger.debug("PromptRouter initialised | few_shot=%s", include_few_shot)

    # ── Language detection ────────────────────────────────────────────────────

    def detect_language(self, text: str) -> str:
        """
        Detect text language: Arabic or English

        Args:
            text:  Text to examine

        Returns:
            'ar' إذا كان عربياً | 'en' otherwise
        """
        if not text:
            return "ar"
        arabic_chars = len(_ARABIC_RE.findall(text))
        ratio = arabic_chars / max(len(text.replace(" ", "")), 1)
        lang = "ar" if ratio > 0.25 else "en"
        logger.debug("detect_language: ratio=%.2f → %s", ratio, lang)
        return lang

    # ── Question type detection ───────────────────────────────────────────────

    def detect_question_type(self, query: str, language: Optional[str] = None) -> QuestionType:
        """
        Classify the question type

        Args:
            query:     Query text
            language: 'ar' | 'en' | None (auto-detect)

        Returns:
            QuestionType
        """
        if not query:
            return QuestionType.GENERAL

        lang = language or self.detect_language(query)
        patterns = _PATTERNS_AR if lang == "ar" else _PATTERNS_EN

        for q_type, pattern in patterns:
            if pattern.search(query):
                logger.debug("detect_question_type: matched %s", q_type.value)
                return q_type

        return QuestionType.GENERAL

    # ── Prompt building ───────────────────────────────────────────────────────

    def build(
        self,
        query: str,
        context: str,
        language: Optional[str] = None,
        question_type: Optional[QuestionType] = None,
    ) -> str:
        """
        Build the appropriate prompt

        Args:
            query:          User query
            context:       Retrieved context
            language:      'ar' | 'en' | None (auto-detect)
            question_type: Override type detection

        Returns:
            str: Prompt Ready-to-send LLM
        """
        lang     = language      or self.detect_language(query)
        q_type   = question_type or self.detect_question_type(query, lang)

        few_shot = ""
        if self.include_few_shot:
            store    = _FEW_SHOT_AR if lang == "ar" else _FEW_SHOT_EN
            few_shot = store.get(q_type, "")

        if lang == "ar":
            prompt = self._build_arabic(query, context, q_type, few_shot)
        else:
            prompt = self._build_english(query, context, q_type, few_shot)

        logger.debug("build: lang=%s | type=%s | prompt_len=%d", lang, q_type.value, len(prompt))
        return prompt

    # ── Internal builders ─────────────────────────────────────────────────────

    def _build_arabic(
        self,
        query: str,
        context: str,
        q_type: QuestionType,
        few_shot: str,
    ) -> str:
        """ Arabic template per question type"""

        instruction_map = {
            QuestionType.FACTUAL:      "أجب بدقة واختصار بناءً على المعلومات المتاحة فقط.",
            QuestionType.ANALYTICAL:   "حلّل الموضوع وقدّم أسبابه وتداعياته بوضوح.",
            QuestionType.COMPARATIVE:  "قارن بين العناصر مع إبراز أوجه التشابه والاختلاف.",
            QuestionType.PROCEDURAL:   "اشرح الخطوات بترتيب منطقي وبأسلوب واضح.",
            QuestionType.DEFINITIONAL: "عرّف المفهوم ثم وضّحه بمثال إن أمكن.",
            QuestionType.EVALUATIVE:   "قيّم الموضوع مع ذكر الإيجابيات والسلبيات.",
            QuestionType.CAUSAL:       "اشرح الأسباب والنتائج بوضوح.",
            QuestionType.GENERAL:      "أجب بدقة ووضوح بناءً على المعلومات المتاحة.",
        }
        instruction = instruction_map.get(q_type, instruction_map[QuestionType.GENERAL])

        return (
            f"أنت مساعد ذكي متخصص في الإجابة الدقيقة على الأسئلة.\n\n"
            f"التعليمات: {instruction}\n\n"
            f"القواعد:\n"
            f"• اعتمد فقط على المعلومات المقدمة.\n"
            f"• إذا لم تجد معلومات كافية قل: «لا توجد معلومات كافية للإجابة».\n"
            f"• أجب باللغة العربية.\n\n"
            f"{few_shot}"
            f"المعلومات المتاحة:\n{context}\n\n"
            f"السؤال: {query}\n"
            f"الإجابة:"
        )

    def _build_english(
        self,
        query: str,
        context: str,
        q_type: QuestionType,
        few_shot: str,
    ) -> str:
        """English template per question type"""

        instruction_map = {
            QuestionType.FACTUAL:      "Answer factually and concisely using only the provided information.",
            QuestionType.ANALYTICAL:   "Analyse the topic and present causes, effects, and insights clearly.",
            QuestionType.COMPARATIVE:  "Compare the elements, highlighting similarities and differences.",
            QuestionType.PROCEDURAL:   "Explain the steps in logical order with clear language.",
            QuestionType.DEFINITIONAL: "Define the concept and illustrate it with an example if possible.",
            QuestionType.EVALUATIVE:   "Evaluate the topic, listing pros and cons where relevant.",
            QuestionType.CAUSAL:       "Explain the causes and effects clearly.",
            QuestionType.GENERAL:      "Answer accurately and clearly using the provided information.",
        }
        instruction = instruction_map.get(q_type, instruction_map[QuestionType.GENERAL])

        return (
            f"You are an intelligent assistant specialised in accurate question answering.\n\n"
            f"Instruction: {instruction}\n\n"
            f"Rules:\n"
            f"• Base your answer solely on the provided information.\n"
            f"• If information is insufficient, say: \"Insufficient information to answer.\"\n"
            f"• Answer in English.\n\n"
            f"{few_shot}"
            f"Available Information:\n{context}\n\n"
            f"Question: {query}\n"
            f"Answer:"
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"PromptRouter(few_shot={self.include_few_shot})"
