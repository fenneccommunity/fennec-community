from typing import Any, Dict
from dataclasses import dataclass, field


@dataclass
class Document:
    """
    Unified document representation.

    Attributes:
        text:     Raw text content.
        score:    Relevance score in [0, 1].
        metadata: Optional key-value metadata.
        source:   Origin identifier (e.g. chunk ID, file name).
    """
    text: str
    score: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    source: str = ""

    def snippet(self, max_chars: int = 300) -> str:
        """Return a truncated preview of the text."""
        return self.text[:max_chars] + ("…" if len(self.text) > max_chars else "")
