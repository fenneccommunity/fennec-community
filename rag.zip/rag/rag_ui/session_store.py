from __future__ import annotations
import json
import threading
from pathlib import Path
from typing import Dict, List, Optional

from .dataclass import ChatSession


class SessionStore:
    """
    مخزن جلسات آمن في الذاكرة مع دعم التزامن.
    Thread-safe in-memory session store with LRU eviction.

    Args:
        max_sessions  : الحد الأقصى للجلسات (يُزيل الأقدم غير المثبّتة عند التجاوز)
        persist_path  : مسار ملف JSON للحفظ الدائم (اختياري)
    """

    def __init__(
        self,
        max_sessions: int = 30,
        persist_path: Optional[str] = None,
    ) -> None:
        self._sessions: Dict[str, ChatSession] = {}
        self._max       = max_sessions
        self._lock      = threading.RLock()
        self._persist   = Path(persist_path) if persist_path else None

        if self._persist and self._persist.exists():
            self._load_from_disk()

    # ── CRUD ──────────────────────────────────────────────────────────────────

    def create(self) -> ChatSession:
        """إنشاء جلسة جديدة وتخزينها (مع إخلاء الأقدم غير المثبّتة عند الامتلاء)."""
        with self._lock:
            if len(self._sessions) >= self._max:
                # يحذف الأقدم فقط من الجلسات غير المثبّتة
                unpinned = [
                    s for s in self._sessions.values() if not s.is_pinned
                ]
                if unpinned:
                    oldest = min(unpinned, key=lambda s: s.updated_at)
                    del self._sessions[oldest.session_id]
            session = ChatSession()
            self._sessions[session.session_id] = session
            return session

    def get(self, sid: str) -> Optional[ChatSession]:
        """الحصول على جلسة بالمعرّف أو None."""
        return self._sessions.get(sid)

    def delete(self, sid: str) -> bool:
        """حذف جلسة. تُرجع True عند النجاح."""
        with self._lock:
            if sid in self._sessions:
                del self._sessions[sid]
                self._save_to_disk()
                return True
        return False

    def rename(self, sid: str, new_title: str) -> bool:
        """إعادة تسمية جلسة. تُرجع True عند النجاح."""
        session = self.get(sid)
        if session:
            session.rename(new_title)
            self._save_to_disk()
            return True
        return False

    def pin(self, sid: str, pinned: bool = True) -> bool:
        """تثبيت / إلغاء تثبيت جلسة."""
        session = self.get(sid)
        if session:
            session.is_pinned = pinned
            self._save_to_disk()
            return True
        return False

    def rate_message(self, sid: str, msg_id: str, rating: int) -> bool:
        """تقييم رسالة داخل جلسة معيّنة."""
        session = self.get(sid)
        if session:
            result = session.rate_message(msg_id, rating)
            if result:
                self._save_to_disk()
            return result
        return False

    # ── Query ─────────────────────────────────────────────────────────────────

    def list_sorted(self) -> List[ChatSession]:
        """
        قائمة الجلسات مرتبةً:
        المثبّتة أولًا ← ثم تنازليًا حسب آخر تحديث.
        """
        return sorted(
            self._sessions.values(),
            key=lambda s: (not s.is_pinned, s.updated_at),
            reverse=False,
        )[::-1]

    def search(self, query: str) -> List[ChatSession]:
        """
        البحث النصي عبر عناوين الجلسات ومحتوى رسائلها.

        Args:
            query: نص البحث (غير حساس لحالة الأحرف)

        Returns:
            قائمة الجلسات المطابقة مرتّبة تنازليًا
        """
        q = query.strip().lower()
        if not q:
            return self.list_sorted()

        results: List[ChatSession] = []
        for session in self._sessions.values():
            if q in session.title.lower():
                results.append(session)
                continue
            if any(q in m.content.lower() for m in session.messages):
                results.append(session)

        return sorted(results, key=lambda s: s.updated_at, reverse=True)

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def count(self) -> int:
        return len(self._sessions)

    @property
    def total_messages(self) -> int:
        return sum(s.message_count for s in self._sessions.values())

    # ── Persistence ───────────────────────────────────────────────────────────

    def save(self) -> None:
        """حفظ يدوي للجلسات على القرص."""
        self._save_to_disk()

    def _save_to_disk(self) -> None:
        if not self._persist:
            return
        try:
            data = [s.to_dict() for s in self._sessions.values()]
            self._persist.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            import logging
            logging.getLogger(__name__).warning("Failed to persist sessions: %s", exc)

    def _load_from_disk(self) -> None:
        try:
            data = json.loads(self._persist.read_text(encoding="utf-8"))
            for item in data:
                session = ChatSession.from_dict(item)
                self._sessions[session.session_id] = session
        except Exception as exc:
            import logging
            logging.getLogger(__name__).warning("Failed to load sessions from disk: %s", exc)