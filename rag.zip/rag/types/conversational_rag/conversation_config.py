from dataclasses import dataclass

@dataclass
class RAGConfigConverstion:
    """
    Conversational RAG System Configuration
    """
    # إعدادات التاريخ | History settings
    max_history_turns: int = 10        # الحد الأقصى لعدد دورات المحادثة المحفوظة
                                       # Maximum number of saved conversation turns
    context_turns: int = 3             # عدد الدورات المستخدمة في السياق
                                       # Number of turns used in context
    # إعدادات السياق | Context settings
    enable_context_compression: bool = False  # تفعيل ضغط السياق للمحادثات الطويلة
                                              # Enable context compression for long conversations
    # إعدادات الإجابة | Answer settings
    include_sources: bool = True       # إضافة المصادر للإجابة
                                       # Include sources in answer
    
    use_history: bool = True           # استخدام تاريخ المحادثة
                                       # Use conversation history
    
    # إعدادات الحفظ | Save settings
    auto_save_history: bool = True     # الحفظ التلقائي للتاريخ
                                       # Auto-save history
    
    history_save_path: str = "conversations"  # مسار حفظ التاريخ
                                              # History save path
