from dataclasses import dataclass
from typing import Any, Dict, List
from .document import Document
from .action_step import ActionStep


@dataclass
class AgenticResult:
    """
    Full result returned by AgenticRAG.query().

    Attributes:
        answer:        Generated answer string.
        retrieved_docs: Final set of docs used for generation.
        action_history: Ordered list of decisions made.
        iterations:    Total iterations consumed.
        reasoning:     Human-readable decision summary.
        confidence:    Estimated confidence of the answer.
        cached:        Whether the result came from cache.
    """
    answer: str
    retrieved_docs: List[Document]
    action_history: List[ActionStep]
    iterations: int
    reasoning: str
    confidence: float = 0.0
    cached: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "answer": self.answer,
            "docs_used": len(self.retrieved_docs),
            "iterations": self.iterations,
            "confidence": round(self.confidence, 4),
            "cached": self.cached,
            "reasoning": self.reasoning,
        }
