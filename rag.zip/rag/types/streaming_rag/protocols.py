from typing import (
    Any, AsyncIterator, Dict, Iterator, Optional, Protocol, runtime_checkable,
)



@runtime_checkable
class Retrievable(Protocol):
    def retrieve(self, query: str) -> Any: ...


@runtime_checkable
class Queryable(Protocol):     # like a retriever but with more context
    def query(self, query: str, context: Optional[Dict] = None) -> Any: ...


@runtime_checkable
class SyncStreamableLLM(Protocol):
    def stream(self, prompt: str) -> Iterator[str]: ...


@runtime_checkable
class AsyncStreamableLLM(Protocol):
    async def astream(self, prompt: str) -> AsyncIterator[str]: ...
