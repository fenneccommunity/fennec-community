# -*- coding: utf-8 -*-
"""
Retrieval Result Cache

Strategy:
  - TTL-based in-memory LRU cache.
  - Key = normalized(query) + top_k.
  - Thread-safe with RLock.
"""
from __future__ import annotations
import hashlib
import re
import time
from collections import OrderedDict
from threading import RLock
from typing import Any, Dict, List, Optional, Tuple
from .logger import get_logger
logger = get_logger(__name__)


def _normalize_query(query: str) -> str:
    """Normalize query for cache key."""
    return re.sub(r"\s+", " ", query.strip().lower())


def _make_key(query: str, top_k: int) -> str:
    raw = f"{_normalize_query(query)}|topk={top_k}"
    return hashlib.md5(raw.encode()).hexdigest()


class RetrievalCache:
    """
    TTL-aware LRU cache for retrieval results.

    Args:
        maxsize:  Maximum number of cached queries. Default 256.
        ttl:      Seconds before a cached result expires. Default 300 (5 min).
                  Set to None to disable expiry.

    Example::

        cache = RetrievalCache(maxsize=512, ttl=600)
        cached = cache.get("رقم هاتف محمد", top_k=5)
        if cached is None:
            result = vector_db.search(...)
            cache.set("رقم هاتف محمد", top_k=5, results=result)
    """

    def __init__(self, maxsize: int = 256, ttl: Optional[float] = 300.0) -> None:
        self.maxsize = maxsize
        self.ttl     = ttl
        self._lock   = RLock()
        # OrderedDict: key → (results, inserted_at)
        self._store: OrderedDict[str, Tuple[List[Tuple[Any, float]], float]] = OrderedDict()
        self._hits   = 0
        self._misses = 0

        logger.info(
            "RetrievalCache initialised | maxsize=%d | ttl=%s",
            maxsize, f"{ttl}s" if ttl else "∞",
        )

    # ── Public API ────────────────────────────────────────────────────────────

    def get(self, query: str, top_k: int) -> Optional[List[Tuple[Any, float]]]:
        """
        Return cached results, or None if absent / expired.
        """
        key = _make_key(query, top_k)
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None

            results, inserted_at = entry
            if self.ttl is not None and (time.monotonic() - inserted_at) > self.ttl:
                del self._store[key]
                self._misses += 1
                logger.debug("RetrievalCache | TTL expired | key=%s", key[:8])
                return None

            # LRU: move to end
            self._store.move_to_end(key)
            self._hits += 1
            logger.debug(
                "RetrievalCache | HIT | query=%r | hits=%d | misses=%d",
                query[:40], self._hits, self._misses,
            )
            return results

    def set(
        self,
        query: str,
        top_k: int,
        results: List[Tuple[Any, float]],
    ) -> None:
        """
        Store results and evict the oldest entry if at capacity.
        """
        key = _make_key(query, top_k)
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            self._store[key] = (results, time.monotonic())
            if len(self._store) > self.maxsize:
                oldest = next(iter(self._store))
                del self._store[oldest]
                logger.debug("RetrievalCache | evicted oldest entry")

    def invalidate(self, query: str, top_k: int) -> bool:
        """Invalidate a specific entry."""
        key = _make_key(query, top_k)
        with self._lock:
            if key in self._store:
                del self._store[key]
                return True
            return False

    def clear(self) -> None:
        """Clear the entire cache."""
        with self._lock:
            self._store.clear()
            self._hits   = 0
            self._misses = 0
        logger.info("RetrievalCache cleared")

    def stats(self) -> Dict[str, Any]:
        """Cache statistics."""
        with self._lock:
            total = self._hits + self._misses
            return {
                "size":      len(self._store),
                "maxsize":   self.maxsize,
                "ttl":       self.ttl,
                "hits":      self._hits,
                "misses":    self._misses,
                "hit_rate":  round(self._hits / total, 3) if total else 0.0,
            }

    def __repr__(self) -> str:
        s = self.stats()
        return (
            f"RetrievalCache(size={s['size']}/{s['maxsize']}, "
            f"hit_rate={s['hit_rate']:.1%})"
        )
