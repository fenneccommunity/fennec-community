from dataclasses import dataclass, field
from typing import Optional
from .agentic_config import AgentAction


@dataclass
class ActionStep:
    """Record of a single agent decision."""
    iteration: int
    action: AgentAction
    query: str
    details: str = ""
    duration_ms: float = 0.0
    confidence: float = 0.0          # ثقة العميل في هذه الخطوة
    refined_query: Optional[str] = None  # الاستعلام المحسّن إن وُجد
