import re
import logging
from typing import List

logger = logging.getLogger(__name__)

try:
    import stanza
    STANZA_AVAILABLE = True
except ImportError:
    STANZA_AVAILABLE = False
    logger.warning("Stanza is not installed. Simple entity extraction will be used instead")


class QueryDecomposer:
    """
    Query analyzer with Named Entity Recognition support
    """
    
    # كلمات دلالية للاستعلامات المركبة
    # Keywords for composite queries
    COMPOSITE_INDICATORS = [
        'ثم', 'بعد ذلك', 'ومن ثم', 'وبعدها', 'في الخطوة التالية', 'التالي',
        'وأيضاً', 'كذلك', 'بالإضافة', 'علاوة على', 'فضلاً عن ذلك', 'كما أن', 'مع ذلك',
        'كيف', 'لماذا', 'ما السبب في', 'ما النتيجة', 'بماذا', 'ما الطريقة',
        'إذا', 'في حالة', 'بينما', 'مقارنةً بـ',
        'وبعدين', 'بعد كده', 'بعدها', 'بعد كده على طول', 'وبعدين على طول', 'التالي',
        'وكمان', 'كمان', 'كمان كده', 'برضه', 'كمان ده', 'كمان كده كده',
        'ليه', 'ازاي', 'علشان كده', 'علشان ايه', 'هو ليه', 'عشان كده كده',
        'لو', 'في حالة', 'لو حصل كده', 'لو لأ', 'بينما',
        'وبعدين', 'عقبها', 'بعدين', 'بعدين مباشرة', 'التالي',
        'وكمان', 'بعد كذا', 'برضه', 'كذلك',
        'ليش', 'شلون', 'كيف', 'علشان كذا', 'ليه',
        'لو', 'اذا', 'في حال', 'بينما',
        'وبعدين', 'بعدين', 'عقب هيك', 'بعد هيك', 'التالي',
        'وكمان', 'كمان', 'بعد كذا', 'برضه',
        'ليش', 'كيف', 'ليه', 'عشان هيك',
        'لو', 'إذا', 'في حال', 'بينما'
    ]
    
    # أوزان أنواع الكيانات
    # Entity type weights
    ENTITY_TYPE_WEIGHTS = {
        'PERS': 3.0,      # أشخاص - الأهم | Persons - Most important
        'PER': 3.0,       # أشخاص (تسمية بديلة) | Persons (alternative naming)
        'ORG': 2.5,       # منظمات | Organizations
        'LOC': 2.0,       # أماكن | Locations
        'GPE': 2.0,       # كيانات جيوسياسية | Geo-political entities
        'DATE': 1.5,      # تواريخ | Dates
        'TIME': 1.2,      # أوقات | Time
        'MONEY': 1.5,     # مبالغ مالية | Money amounts
        'PERCENT': 1.2,   # نسب مئوية | Percentages
        'QUANTITY': 1.3,  # كميات | Quantities
        'CARDINAL': 1.1,  # أرقام | Cardinal numbers
        'ORDINAL': 1.0    # ترتيب | Ordinal numbers
    }
    
    def __init__(self, use_stanza: bool = True, language: str = 'ar'):
        """
        Initialize query decomposer
        
        Args:
            use_stanza: Use Stanza for extraction (if available)
            language: Language ('ar' for Arabic, 'en' for English)
        """
        self.use_stanza = use_stanza and STANZA_AVAILABLE
        self.language = language
        self.nlp = None
        
        if self.use_stanza:
            try:
                logger.info(f"Loading Stanza model ({language})...")
                self.nlp = stanza.Pipeline(
                    language,
                    processors='tokenize,ner',
                    verbose=False,
                    download_method=None
                )
                logger.info("✓ Stanza loaded successfully")
            except Exception as e:
                logger.warning(f"Failed to load Stanza: {e}")
                logger.warning("Simple extraction will be used")
                self.nlp = None
        else:
            if not STANZA_AVAILABLE:
                logger.info("Stanza is not available. For better accuracy, install it:")
                logger.info("pip install stanza && python -c 'import stanza; stanza.download(\"ar\")'")
    
    def decompose(self, query: str) -> List[str]:
        """
        Decompose query into sub-queries
        
        Args:
            query:  Original query
            
        Returns: List of sub-queries
        """
        # البحث عن كلمات دلالية
        # Search for indicator keywords
        for indicator in self.COMPOSITE_INDICATORS:
            if indicator in query:
                parts = query.split(indicator, 1)
                if len(parts) == 2:
                    return [parts[0].strip(), parts[1].strip()]
        
        # إذا لم يكن مركباً
        # If not composite
        return [query]
    
    def extract_entities(self, text: str) -> List[str]:
        """
        Extract entities from text
        Uses Stanza if available, otherwise uses simple regex
        
        Args:
            text:  Text to extract entities from
            
        Returns:
            List of extracted entities
        """
        if not text or len(text.strip()) < 3:
            return []
        
        # استخدام Stanza إذا كان متاحاً
        # Use Stanza if available
        if self.nlp is not None:
            return self._extract_with_stanza(text)
        else:
            # Fallback: استخراج بسيط
            # Fallback: Simple extraction
            return self._extract_with_regex(text)
    
    def _extract_with_stanza(self, text: str) -> List[str]:
        """
        Extract entities using Stanza NER
        
        Args:
            text: Text
            
        Returns:
             List of entities
        """
        try:
            doc = self.nlp(text)
            entity_scores = []
            
            # معالجة كل جملة واستخراج الكيانات
            # Process each sentence and extract entities
            for sentence in doc.sentences:
                for entity in sentence.ents:
                    # حساب درجة أهمية الكيان
                    # Calculate entity importance score
                    score = self._calculate_entity_score(
                        entity.text, 
                        entity.type, 
                        text
                    )
                    entity_scores.append((entity.text, entity.type, score))
            
            # ترتيب حسب الأهمية
            # Sort by importance
            entity_scores.sort(key=lambda x: x[2], reverse=True)
            
            # إرجاع أفضل 10 كيانات (النص فقط)
            # Return top 10 entities (text only)
            entities = [ent[0] for ent in entity_scores[:10]]
            
            logger.debug(f"Stanza extracted {len(entities)} entities")
            return entities
            
        except Exception as e:
            logger.error(f"Error in Stanza NER: {e}")
            return self._extract_with_regex(text)
    
    def _extract_with_regex(self, text: str) -> List[str]:
        """
        Simple extraction using regex (fallback)
        
        Args:
            text:  Text
            
        Returns:
            List of entities
        """
        entities = []
        
        # 1. نصوص بين علامات اقتباس
        #    Texts between quotation marks
        quoted = re.findall(r'"([^"]+)"', text)
        entities.extend(quoted)
        quoted_ar = re.findall(r'«([^»]+)»', text)
        entities.extend(quoted_ar)
        
        # 2. كلمات إنجليزية (غالباً أسماء علم)
        #    English words (usually proper nouns)
        english_words = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', text)
        entities.extend(english_words)
        
        # 3. أرقام (تواريخ، إحصائيات)
        #    Numbers (dates, statistics)
        numbers = re.findall(r'\d+', text)
        entities.extend(numbers)
        
        # إزالة التكرار
        # Remove duplicates
        unique_entities = list(set(entities))
        
        # ترتيب حسب الطول (الأطول = أكثر تحديداً)
        # Sort by length (longer = more specific)
        unique_entities.sort(key=len, reverse=True)
        
        logger.debug(f"Regex استخرج {len(unique_entities)} كيان")
        logger.debug(f"Regex extracted {len(unique_entities)} entities")
        return unique_entities[:10]
    
    def _calculate_entity_score(self, entity_text: str, 
                               entity_type: str, 
                               full_text: str) -> float:
        """
        Calculate entity importance score
        
        Args:
            entity_text:  Entity text
            entity_type:  Entity type
            full_text:  Full text
            
        Returns:
            Importance score
        """
        score = 0.0
        
        # 1. وزن نوع الكيان
        #    Entity type weight
        score += self.ENTITY_TYPE_WEIGHTS.get(entity_type, 1.0)
        
        # 2. طول الكيان (الأطول = أكثر تحديداً)
        #    Entity length (longer = more specific)
        score += len(entity_text) / 10
        
        # 3. تكرار الكيان في النص
        #    Entity frequency in text
        count = full_text.count(entity_text)
        score += count * 0.5
        
        # 4. الكلمات الإنجليزية (غالباً مصطلحات مهمة)
        #    English words (usually important terms)
        if re.search(r'[A-Za-z]', entity_text):
            score += 1.0
        
        # 5. الأرقام (تواريخ، إحصائيات)
        #    Numbers (dates, statistics)
        if re.search(r'\d', entity_text):
            score += 0.5
        
        return score
    
    def get_entities_by_type(self, text: str) -> dict:
        """
        Extract entities classified by type
        Useful for better understanding text content
        
        Args:
            text:  Text
            
        Returns:
            Dictionary of entities by type
        """
        if self.nlp is None:
            return {}
        
        try:
            doc = self.nlp(text)
            entities_by_type = {}
            
            # معالجة كل جملة
            # Process each sentence
            for sentence in doc.sentences:
                for entity in sentence.ents:
                    if entity.type not in entities_by_type:
                        entities_by_type[entity.type] = []
                    entities_by_type[entity.type].append(entity.text)
            
            # إزالة التكرار
            # Remove duplicates
            for ent_type in entities_by_type:
                entities_by_type[ent_type] = list(set(entities_by_type[ent_type]))
            
            return entities_by_type
            
        except Exception as e:
            logger.error(f"Error in get_entities_by_type: {e}")
            return {}

