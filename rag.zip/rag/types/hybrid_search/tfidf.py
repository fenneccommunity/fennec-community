from typing import List
import logging
from collections import Counter
import math
from .stanze_ import StanzaTokenizer

logger = logging.getLogger(__name__)

class TFIDFScorer:
    """
    TF-IDF for keyword search
    """
    def __init__(self, language: str = 'ar', use_lemmatization: bool = True):
        """
        Initialize TF-IDF
        
        Args:
            language:  Language
            use_lemmatization:  Use lemmatization
        """
        self.language = language
        self.idf = {}              # معامل IDF | IDF coefficient
        self.corpus_size = 0       # حجم المجموعة | Corpus size
        
        # إنشاء المحلل النصي
        # Create tokenizer
        self.tokenizer = StanzaTokenizer(language=language, use_lemmatization=use_lemmatization)
        
        logger.info(f"✅ TF-IDF initialized with Stanza tokenizer ({language})")
    
    def fit(self, documents: List[str]):
        """
        Train TF-IDF model
        
        Args:
            documents:  List of documents
        """
        logger.info(f"🔄 Training TF-IDF on {len(documents)} documents...")
        
        self.corpus_size = len(documents)
        df = Counter()
        
        # حساب تكرار المستندات
        # Calculate document frequency
        for doc in documents:
            terms = set(self.tokenizer.tokenize(doc))
            for term in terms:
                df[term] += 1
        
        # IDF = log((N + 1) / (df + 1)) + 1  — smoothed to avoid Inf and zero
        for term, freq in df.items():
            self.idf[term] = math.log((self.corpus_size + 1) / (freq + 1)) + 1
        
        logger.info(f"✅ TF-IDF training completed with {self.corpus_size} documents ")
        logger.info(f"📊 Vocabulary size: {len(self.idf)} terms ")
    
    def batch_score(self, query: str, documents: List[str]) -> List[float]:
        """
        Calculate TF-IDF scores for a batch of documents
        
        Args:
            query:  Query
            documents: List of documents
            
        Returns:
            List of scores
        """
        return [self.score(query, doc) for doc in documents]

    def score(self, query: str, document: str) -> float:
        """
        Calculate TF-IDF score
        
        Args:
            query:  Query
            document:  Document
            
        Returns:
            TF-IDF score
        """
        query_terms = self.tokenizer.tokenize(query)
        doc_terms = self.tokenizer.tokenize(document)
        term_freq = Counter(doc_terms)
        
        score = 0.0
        for term in query_terms:
            if term in self.idf:
                # TF = (عدد مرات الكلمة) / (طول المستند)
                # TF = (term count) / (document length)
                tf = term_freq.get(term, 0) / max(len(doc_terms), 1)
                score += tf * self.idf[term]
        
        return score