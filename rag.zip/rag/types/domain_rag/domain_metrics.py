from dataclasses import dataclass , field
from typing import Any, Dict, List


@dataclass
class DomainMetrics:
    total_queries: int = 0
    rejected_queries: int = 0   # الطلبات المرفوضه بنائا علي stritic_mode
    total_docs_used: int = 0
    errors: int = 0
    avg_relevance: float = 0.0
    _relevances: List[float] = field(default_factory=list)

    def record(self, relevance: float, docs: int, rejected: bool = False):
        self.total_queries += 1
        self.total_docs_used += docs
        if rejected:
            self.rejected_queries += 1
        self._relevances.append(relevance)
        self.avg_relevance = sum(self._relevances) / len(self._relevances)

    def summary(self) -> Dict[str, Any]:
        return {
            "total_queries": self.total_queries,
            "rejected": self.rejected_queries,
            "acceptance_rate": f"{(1 - self.rejected_queries / max(self.total_queries, 1)):.1%}",
            "avg_relevance": round(self.avg_relevance, 3),
            "avg_docs_per_query": round(self.total_docs_used / max(self.total_queries, 1), 1),
            "errors": self.errors,
        }