from __future__ import annotations
import hashlib
import time
from typing import Any, Dict, List, Optional, Tuple

from .document import Document



class TTLCache:
    """Thread-unsafe, in-process TTL cache for retrieval results."""

    def __init__(self, ttl_seconds: int = 300) -> None:
        self._store: Dict[str, Tuple[Any, float]] = {}
        self.ttl = ttl_seconds

    def _key(self, query: str) -> str:
        return hashlib.sha256(query.encode()).hexdigest()

    def get(self, query: str) -> Optional[List[Document]]:
        key = self._key(query)
        if key in self._store:
            value, ts = self._store[key]
            if time.time() - ts < self.ttl:
                return value
            del self._store[key]
        return None

    def set(self, query: str, docs: List[Document]) -> None:
        self._store[self._key(query)] = (docs, time.time())

    def clear(self) -> None:
        self._store.clear()
