"""
Domain Specific RAG 
"""

from __future__ import annotations
import asyncio
import logging
import time
from typing import Any, Dict, List, Optional, Set, Tuple
from .domain_defination import DomainDefinition, PRESET_DOMAINS
from .domain_metrics import DomainMetrics
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
#  الكلاس الرئيسي
# ─────────────────────────────────────────────

class DomainSpecificRAG:
    """

    Using:
    ──────────────────
    1. ready domain (Preset):
       >>> rag = DomainSpecificRAG(sys, domain="medical")

    2. define simple domain:
       >>> rag = DomainSpecificRAG(sys, domain="nutrition",
       ...         domain_terms=["بروتين","كربوهيدرات","فيتامين"])

    3. define complex domain:
       >>> domain = DomainDefinition(
       ...     name="cooking",
       ...     display_name="الطبخ والمطبخ",
       ...     terms=["وصفة","مكونات","طبخ","تتبيلة"],
       ...     system_prompt="أنت طاهٍ محترف...",
       ... )
       >>> rag = DomainSpecificRAG(sys, domain=domain)

    4. load domain from json file:
       >>> domain = DomainDefinition.load("cooking.json")
       >>> rag = DomainSpecificRAG(sys, domain=domain)

    5. multi domain:
       >>> rag = MultiDomainRAG(sys, domains=[domain1, domain2])
    """

    def __init__(
        self,
        rag_system,
        domain: str | DomainDefinition,
        domain_terms: Optional[List[str]] = None,
        llm=None,
        strict_mode: bool = False,
        auto_expand_terms: bool = False,
    ):
        """
        Args:
            rag_system:          backend main rag system
            domain:              define full domain 
            domain_terms:         term for domain
            llm:                  llm provider 
            strict_mode:          strict mode for domain
            auto_expand_terms:    auto expand domain
        """
        self.rag_system = rag_system
        self.llm = llm or getattr(rag_system, "llm", None)
        self.strict_mode = strict_mode
        self.metrics = DomainMetrics()

        # ── بناء DomainDefinition ─────────────
        self.domain_def = self._resolve_domain(domain, domain_terms)

       
        if auto_expand_terms and self.llm:
            asyncio.run(self._auto_expand_terms())

        logger.info(
            "🎯 DomainSpecificRAG ready | domain='%s' | terms=%d | strict=%s",
            self.domain_def.display_name,
            len(self.domain_def.all_terms),
            strict_mode,
        )

    # ─────────────────────────────────────────
    #  Public API
    # ─────────────────────────────────────────

    def query(self, query: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        """ 
           query a domain-specific domain
        """
        return asyncio.run(self.aquery(query, context))

    async def aquery(
        self, query: str, context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Async domain-specific query.
        """
        logger.info("🎯 [%s] query: %.80s", self.domain_def.name, query)
        start = time.perf_counter()

        # 1. قياس الصلة | Measure relevance
        relevance, matched_terms = self._measure_relevance(query)

        # 2. رفض إن لزم | Reject if needed
        if self.strict_mode and relevance < self.domain_def.min_relevance:
            self.metrics.record(relevance, 0, rejected=True)
            return self._rejection_response(relevance)

        # 3. توسيع الاستعلام | Expand query
        enhanced_query = self._enhance_query(query, matched_terms)

        # 4. الاسترجاع | Retrieve
        docs = await self._retrieve(enhanced_query)

        # 5. تصفية وترتيب | Filter & rank
        docs = self._rank_by_domain(docs)

        # 6. توليد الإجابة | Generate
        answer_data = await self._generate(query, docs, context)

        latency_ms = round((time.perf_counter() - start) * 1000, 2)
        self.metrics.record(relevance, len(docs))

        return {
            **answer_data,
            "domain": self.domain_def.name,
            "domain_display": self.domain_def.display_name,
            "domain_relevance": round(relevance, 3),
            "matched_terms": list(matched_terms),
            "enhanced_query": enhanced_query,
            "docs_count": len(docs),
            "latency_ms": latency_ms,
        }

    def add_document(self, text: str, metadata: Optional[Dict] = None) -> Any:
        """
          add document with auto-generated metadata
        """
        if not text or not text.strip():
            raise ValueError("the text must not be empty")
        meta = {**(metadata or {}), "domain": self.domain_def.name}
        return self.rag_system.add_document(text, meta)

    def add_terms(self, *terms: str):
        """
          add new terms to the domain in runtime
        """
        self.domain_def.add_terms(*terms)
        logger.info("➕ Added %d terms to domain '%s'", len(terms), self.domain_def.name)

    def add_synonym(self, term: str, *synonyms: str):
        """
          add synonyms to a term in runtime
        """
        self.domain_def.add_synonym(term, *synonyms)

    def get_metrics(self) -> Dict[str, Any]:
        """
          domain metrics summary
        """
        return {
            "domain": self.domain_def.name,
            **self.metrics.summary(),
            "total_terms": len(self.domain_def.all_terms),
        }

    def save_domain(self, path: str):
        """
           save a domain in json file
        """
        self.domain_def.save(path)

    # ─────────────────────────────────────────
    #  Private: Domain Resolution
    # ─────────────────────────────────────────

    @staticmethod
    def _resolve_domain(
        domain: str | DomainDefinition,
        extra_terms: Optional[List[str]],
    ) -> DomainDefinition:
        """تحويل أي شكل من أشكال الإدخال إلى DomainDefinition"""
        if isinstance(domain, DomainDefinition):
            definition = domain
        elif isinstance(domain, str):
            if domain in PRESET_DOMAINS:
                # نسخ حتى لا نعدّل الـ preset الأصلي
                definition = DomainDefinition.from_dict(
                    PRESET_DOMAINS[domain].to_dict()
                )
            else:
                # مجال مخصص جديد باسم فقط
                logger.warning(
                    "⚠️ Domain '%s' not in presets — creating minimal definition. "
                    "Consider using DomainDefinition for full control.",
                    domain,
                )
                definition = DomainDefinition(name=domain, terms=[])
        else:
            raise TypeError(
                f"domain must be str or DomainDefinition, got {type(domain)}"
            )

        # إضافة المصطلحات الإضافية
        if extra_terms:
            definition.add_terms(*extra_terms)

        return definition

    # ─────────────────────────────────────────
    #  Private: Relevance
    # ─────────────────────────────────────────

    def _measure_relevance(self, query: str) -> Tuple[float, Set[str]]:
        """
        قياس صلة الاستعلام بالمجال — متعدد الطبقات.
        Returns (score 0-1, matched_terms)
        """
        query_words = set(query.lower().split())
        all_terms = self.domain_def.all_terms

        if not all_terms or not query_words:
            return (0.0, set())

        # طبقة 1: تطابق مباشر
        direct_matches = query_words & all_terms

        # طبقة 2: تطابق جزئي (term موجود كجزء من كلمة في السؤال)
        partial_matches: Set[str] = set()
        for term in all_terms:
            for word in query_words:
                if term in word or word in term:
                    partial_matches.add(term)

        matched = direct_matches | partial_matches
        if not matched:
            return (0.0, set())

        # النتيجة: نسبة التطابق مع تعزيز للتطابق المباشر
        score = (len(direct_matches) * 1.0 + len(partial_matches) * 0.5) / len(query_words)
        score = min(score * self.domain_def.boost_weight, 1.0)

        return (score, matched)

    # ─────────────────────────────────────────
    #  Private: Query Enhancement
    # ─────────────────────────────────────────

    def _enhance_query(self, query: str, matched_terms: Set[str]) -> str:
        """توسيع الاستعلام بالمصطلحات الصالحة"""
        if not matched_terms:
            # إضافة اسم المجال كسياق ضمني
            return f"[{self.domain_def.display_name}] {query}"

        # إضافة مرادفات المصطلحات المتطابقة
        extra: List[str] = []
        for term in list(matched_terms)[:3]:
            syns = self.domain_def.synonyms.get(term, [])
            extra.extend(syns[:2])

        suffix = " ".join(dict.fromkeys(extra))  # مع الحفاظ على الترتيب
        enhanced = f"{query} {suffix}".strip() if suffix else query

        logger.debug("✨ Enhanced query: %s → %s", query[:50], enhanced[:80])
        return enhanced[:600]

    # ─────────────────────────────────────────
    #  Private: Retrieval & Ranking
    # ─────────────────────────────────────────

    async def _retrieve(self, query: str) -> List[Dict]:
        """استرجاع غير متزامن مع توحيد شكل البيانات"""
        try:
            raw = await asyncio.to_thread(
                self.rag_system.retrieve, query, top_k=15
            )

            docs = raw.get("results", raw) if isinstance(raw, dict) else raw
            docs = docs or []

            normalized = []

            for doc in docs:
                # الحالة 1: tuple (text, score)
                if isinstance(doc, tuple):
                    if len(doc) == 2:
                        text, score = doc

                        # لو text نفسه object (زي Document)
                        if hasattr(text, "text"):
                            text = text.text

                        normalized.append({
                            "text": text,
                            "score": float(score),
                            "metadata": getattr(doc[0], "metadata", {}) if hasattr(doc[0], "metadata") else {}
                        })
                    else:
                        continue

                # الحالة 2: dict (already good)
                elif isinstance(doc, dict):
                    normalized.append(doc)

                # الحالة 3: object (زي Document)
                elif hasattr(doc, "text"):
                    normalized.append({
                        "text": doc.text,
                        "score": getattr(doc, "score", 0.0),
                        "metadata": getattr(doc, "metadata", {})
                    })

            return normalized

        except Exception as e:
            logger.error("❌ Retrieval error: %s", e)
            self.metrics.errors += 1
            return []

    def _rank_by_domain(self, docs: List[Dict]) -> List[Dict]:
        """ترتيب المستندات بالجمع بين نقاط RAG ونقاط المجال"""
        all_terms = self.domain_def.all_terms
        ranked = []

        for doc in docs:
            doc_words = set(doc.get("text", "").lower().split())
            domain_hits = len(doc_words & all_terms)
            rag_score = doc.get("score", 0.0)

            # نقطة مجمّعة: RAG + مكافأة المجال المُطبَّعة
            domain_bonus = min(domain_hits / max(len(all_terms), 1), 0.4) \
                * self.domain_def.boost_weight
            combined = rag_score + domain_bonus

            ranked.append({
                **doc,
                "domain_hits": domain_hits,
                "domain_bonus": round(domain_bonus, 4),
                "combined_score": round(combined, 4),
            })

        ranked.sort(key=lambda x: x["combined_score"], reverse=True)

        # في الوضع الصارم: حذف المستندات عديمة الصلة
        if self.strict_mode:
            ranked = [d for d in ranked if d["domain_hits"] > 0]

        logger.debug("📄 Ranked %d docs for domain '%s'", len(ranked), self.domain_def.name)
        return ranked[:10]

    # ─────────────────────────────────────────
    #  Private: Generation
    # ─────────────────────────────────────────

    async def _generate(
        self,
        query: str,
        docs: List[Dict],
        extra_context: Optional[Dict],
    ) -> Dict[str, Any]:
        """توليد إجابة متخصصة غير متزامن"""
        if not docs:
            return {
                "answer": self._no_docs_message(),
                "sources": [],
            }
        try:
            ctx: Dict[str, Any] = {
                "retrieved_docs": docs,
                "domain": self.domain_def.name,
                "domain_display": self.domain_def.display_name,
                "system_prompt": self._build_system_prompt(),
                **(extra_context or {}),
            }
            # ✅ حقن اللغة في query مباشرة — الحل الموثوق
            lang_query = self._inject_language(query)
            raw = await asyncio.to_thread(self.rag_system.generate, lang_query, ctx)
            result: Dict = raw if isinstance(raw, dict) else {"answer": str(raw)}

            # إضافة مصادر مختصرة إن لم تكن موجودة
            if "sources" not in result:
                result["sources"] = [
                    {
                        "text": d.get("text", "")[:200],
                        "score": d.get("combined_score", 0),
                        "metadata": d.get("metadata", {}),
                    }
                    for d in docs[:5]
                ]
            return result

        except Exception as e:
            logger.error("❌ Generation error: %s", e)
            self.metrics.errors += 1
            fallback = docs[0].get("text", "")[:300] if docs else ""
            return {"answer": fallback or "error in generation", "error": str(e)}

    # ─────────────────────────────────────────
    #  Private: Auto Term Expansion
    # ─────────────────────────────────────────

    async def _auto_expand_terms(self):
        """توسيع تلقائي للمصطلحات عبر LLM"""
        if not self.domain_def.terms:
            return
        try:
            sample = ", ".join(self.domain_def.terms[:10])
            prompt = (
                f"You are helping expand terminology for the domain "
                f"'{self.domain_def.display_name}'.\n"
                f"Current terms: {sample}\n"
                f"List 10 additional relevant terms in the same language, "
                f"comma-separated, no explanations:"
            )
            raw: str = await asyncio.to_thread(
                lambda: self.llm.generate(prompt).strip()
            )
            new_terms = [t.strip() for t in raw.split(",") if t.strip()]
            if new_terms:
                self.domain_def.add_terms(*new_terms)
                logger.info(
                    "🤖 Auto-expanded terms: +%d for domain '%s'",
                    len(new_terms), self.domain_def.name,
                )
        except Exception as e:
            logger.warning("⚠️ Auto term expansion failed: %s", e)

    # ─────────────────────────────────────────
    #  Private: Helpers
    # ─────────────────────────────────────────

    _LANG_INSTRUCTIONS: Dict[str, str] = {
        "ar": "يجب أن تكون إجابتك باللغة العربية حصراً.",
        "en": "You must respond in English only.",
        "fr": "Vous devez répondre en français uniquement.",
        "de": "Sie müssen ausschließlich auf Deutsch antworten.",
        "es": "Debes responder únicamente en español.",
    }

    def _build_system_prompt(self) -> str:
        """
        Merge domain system_prompt with an explicit language instruction.
        """
        lang = self.domain_def.language or "ar"
        lang_instruction = self._LANG_INSTRUCTIONS.get(
            lang,
            f"You must respond in the following language: {lang}.",
        )
        base = self.domain_def.system_prompt or ""
        return f"{base}\n{lang_instruction}".strip()

    def _inject_language(self, query: str) -> str:
        """
        Reliable fix for English-response bug:
        Embedding the instruction directly in the query string guarantees
        the LLM sees it regardless of how rag_system.generate handles ctx.
        """
        lang = self.domain_def.language or "ar"
        instruction = self._LANG_INSTRUCTIONS.get(
            lang,
            f"You must respond in the following language: {lang}.",
        )
        return f"{instruction}\n{query}"

    def _no_docs_message(self) -> str:
        """
        Returns 'no info' message in the domain's language.
        """
        lang = self.domain_def.language or "ar"
        messages = {
            "en": f"No sufficient information found to answer your question about {self.domain_def.display_name}.",
      
        }
        return messages.get(lang, messages["en"])

    def _rejection_response(self, relevance: float) -> Dict[str, Any]:
        # كانت الحقول matched_terms, enhanced_query, docs_count, latency_ms مفقودة
        return {
            "answer": self.domain_def.rejection_message,
            "domain": self.domain_def.name,
            "domain_display": self.domain_def.display_name,
            "domain_relevance": round(relevance, 3),
            "matched_terms": [],    # ✅ أُضيف
            "enhanced_query": "",   # ✅ أُضيف
            "docs_count": 0,        # ✅ أُضيف
            "latency_ms": 0.0,      # ✅ أُضيف
            "rejected": True,
            "sources": [],
        }

    def __repr__(self) -> str:
        return (
            f"DomainSpecificRAG(domain='{self.domain_def.name}', "
            f"terms={len(self.domain_def.all_terms)}, "
            f"strict={self.strict_mode}, "
            f"queries={self.metrics.total_queries})"
        )

    # ── Async API ────────────────────────────────────────────────────

    async def agenerate(self, query: str, **kwargs) -> str:
        
        result = await self.aquery(query)
        return result.get("answer", "")

    async def aretrieve(self, query: str, **kwargs):

        return await self._retrieve(query)

    async def astream(
        self,
        query: str,
        context: Optional[Dict] = None,
    ):
        """
        Stream the final answer token by token.

        Usage:
            async for token in domain_rag.astream("سؤالك هنا"):
                print(token, end="", flush=True)

        How it works:
            1. It goes through the same steps as `aquery` (relevance → rejection → retrieval → ranking).
            2. If the `rag_system` supports `astream`, the request is delegated directly to it.
            3. Otherwise, a fallback mechanism is used: the full response is generated first, then streamed word by word.

        In case of rejection (`strict_mode`), the `rejection_message` is streamed immediately without retrieval or generation.

        """
        # 1. قياس الصلة | Measure relevance
        relevance, matched_terms = self._measure_relevance(query)

        # 2. رفض فوري عند الحاجة | Immediate rejection if needed
        if self.strict_mode and relevance < self.domain_def.min_relevance:
            self.metrics.record(relevance, 0, rejected=True)
            for word in self.domain_def.rejection_message.split(" "):
                yield word + " "
                await asyncio.sleep(0)
            return

        # 3. توسيع الاستعلام | Expand query
        enhanced_query = self._enhance_query(query, matched_terms)

        # 4. الاسترجاع والترتيب | Retrieve & rank
        docs = await self._retrieve(enhanced_query)
        docs = self._rank_by_domain(docs)

        # 5. تحديث الإحصائيات | Update metrics
        self.metrics.record(relevance, len(docs))

        # 6. البث | Stream
        if not docs:
            # لا توجد مستندات → بث رسالة افتراضية
            msg = f"not found docs: {self.domain_def.display_name}."
            for word in msg.split(" "):
                yield word + " "
                await asyncio.sleep(0)
            return

        # بناء السياق للتمرير لـ rag_system
        stream_context: Dict[str, Any] = {
            "retrieved_docs": docs,
            "domain": self.domain_def.name,
            "domain_display": self.domain_def.display_name,
            "system_prompt": self._build_system_prompt(),
            **(context or {}),
        }

        # ✅ حقن اللغة في query مباشرة — الحل الموثوق
        lang_query = self._inject_language(query)
        rag = self.rag_system

        # الحالة 1: rag_system يدعم astream مباشرةً
        if hasattr(rag, "astream"):
            async for token in rag.astream(lang_query, stream_context):
                yield token

        # الحالة 2: rag_system يدعم stream المتزامن
        elif hasattr(rag, "stream"):
            async def _wrap_sync_stream():
                for token in rag.stream(lang_query, stream_context):
                    yield token

            async for token in _wrap_sync_stream():
                yield token

        # الحالة 3: fallback — توليد كامل ثم بث كلمة كلمة
        else:
            logger.debug(
                "⚡ astream fallback (word-by-word) for domain '%s'",
                self.domain_def.name,
            )
            try:
                raw = await asyncio.to_thread(rag.generate, lang_query, stream_context)
                answer = raw if isinstance(raw, str) else raw.get("answer", "")
            except Exception as e:
                logger.error("❌ astream generation error: %s", e)
                self.metrics.errors += 1
                answer = f"generation error: {e}"

            for word in answer.split(" "):
                yield word + " "
                await asyncio.sleep(0)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        return False