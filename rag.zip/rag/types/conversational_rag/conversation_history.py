from typing import List, Optional
from datetime import datetime
import json
from pathlib import Path
from .conversation_config import RAGConfigConverstion
from .conversation_turn import ConversationTurn
import logging
config = RAGConfigConverstion()
logger = logging.getLogger(__name__)


class ConversationHistory:
    """
    Conversation history manager with live JSON persistence
    """
    
    def __init__(self, max_turns = config.max_history_turns, history_file: Optional[str] = None):
        """
        Initialize history manager
        
        Args:
            max_turns: Maximum number of saved turns
            history_file: JSON file path for auto-save (None = automatic)
        """
        self.max_turns = max_turns
        self.turns: List[ConversationTurn] = []
        
        # تحديد مسار الملف
        # Determine file path
        if history_file is None:
            # إنشاء مجلد conversations إذا لم يكن موجوداً
            # Create conversations folder if it doesn't exist
            conversations_dir = Path("conversations")
            conversations_dir.mkdir(exist_ok=True)
            
            # اسم الملف بناءً على التاريخ والوقت
            # File name based on date and time
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.history_file = conversations_dir / f"conversation_{timestamp}.json"
        else:
            self.history_file = Path(history_file)
            # إنشاء المجلد الأب إذا لم يكن موجوداً
            # Create parent directory if it doesn't exist
            self.history_file.parent.mkdir(parents=True, exist_ok=True)
        
        # تحميل التاريخ السابق إذا وجد
        # Load previous history if exists
        self._load_from_file()
        
        logger.info(f"📁 History file: {self.history_file}")
    
    def _save_to_file(self):
        """
        Save to JSON file
        """
        try:
            data = {
                'session_info': {
                    'created_at': datetime.now().isoformat(),
                    'total_turns': len(self.turns),
                    'max_turns': self.max_turns
                },
                'turns': [turn.to_dict() for turn in self.turns]
            }
            
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            logger.debug(f"💾 Saved turns {len(self.turns)} in {self.history_file}")
            
        except Exception as e:
            logger.error(f"❌ Failed to save to file: {e}")
    
    def _load_from_file(self):
        """
        Load from JSON file
        """
        if not self.history_file.exists():
            logger.info("📝 No history file found, starting new conversation ")
            return
        
        try:
            with open(self.history_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # تحميل الدورات
            # Load turns
            self.turns = [
                ConversationTurn.from_dict(turn_data)
                for turn_data in data.get('turns', [])
            ]
            
            logger.info(f"📂 Loaded turns {len(self.turns)}  from  {self.history_file}")
            
        except Exception as e:
            logger.error(f"❌ Failed to load from file: {e}")
            self.turns = []
    
    def add_turn(self, query: str, answer: str, chunks : List[str] = None, retrieved_chunks: int = 0):
        """
        Add new turn to history and save to file
        
        Args:
            query: Question
            answer: Answer
            retrieved_chunks: Number of retrieved chunks
        """
        turn = ConversationTurn(
            query=query,
            answer=answer,
            timestamp=datetime.now(),
            chunks=chunks,
            retrieved_chunks=retrieved_chunks
        )
        self.turns.append(turn)
        
        # الاحتفاظ فقط بآخر max_turns دورة
        # Keep only the last max_turns
        if len(self.turns) > self.max_turns:
            self.turns = self.turns[-self.max_turns:]
        
        # حفظ فوري بعد كل إضافة (live)
        # Immediate save after each addition (live)
        self._save_to_file()
    
    def get_recent_turns(self, n: int = 3) -> List[ConversationTurn]:
        """
        Get last n turns from history
        
        Args:
            n: Number of turns
            
        Returns: List of recent turns
        """
        return self.turns[-n:] if self.turns else []
    
    def format_for_prompt(self, n: int = 3, language: str = 'ar') -> str:
        """
        Format history for use in prompt
        
        Args:
            n:  Number of turns needed
            language: Language ('ar' or 'en')
            
        Returns: Formatted history text
        """
        recent = self.get_recent_turns(n)
        if not recent:
            return ""
        
        # تنسيق كل دورة
        # Format each turn
        formatted = [f"Q: {turn.query}\nA: {turn.answer}" 
                    for turn in recent]
        
        header = "Conversation History:" if language == 'ar' else "Conversation History:"
        return header + "\n" + "\n\n".join(formatted) + "\n\n"
    
    def clear(self):
        """
        Clear entire history
        """
        self.turns.clear()
        logger.info("🔄 Conversation history cleared")
    
    def get_file_path(self) -> str:
        """
        Get file path
        
        Returns: Full file path
        """
        return str(self.history_file.absolute())

    def __len__(self) -> int:
        """
        Number of turns in history
        """
        return len(self.turns)
