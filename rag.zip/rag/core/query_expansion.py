# -*- coding: utf-8 -*-
"""
Smart Query Expansion
Strategy:
  1. LLM generates semantically equivalent rephrasings (primary).
  2. Falls back to a curated Arabic/English synonym table if the LLM fails
     or is unavailable (zero extra latency, works offline).

"""

from __future__ import annotations
import re
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple
from .logger import get_logger
from .exceptions import QueryExpansionError
from .synonm_table import _SYNONYM_TABLE

logger = get_logger(__name__)



@lru_cache(maxsize=1024)
def _build_synonym_variants(query: str) -> List[str]:
    """
    Replace each recognised keyword in *query* with its synonyms and return
    a list of rephrased queries (deduplicated, original first).
    """
    variants: List[str] = [query]
    lower_q = query.lower()

    for keyword, synonyms in _SYNONYM_TABLE.items():
        # Case-insensitive full-word match
        pattern = re.compile(r'\b' + re.escape(keyword) + r'\b', re.IGNORECASE)
        if pattern.search(lower_q):
            for syn in synonyms:
                new_q = pattern.sub(syn, query, count=1)
                if new_q != query and new_q not in variants:
                    variants.append(new_q)
            # Only expand on the *first* matched keyword to avoid combinatorial explosion
            break

    return variants


# ══════════════════════════════════════════════════════════════════════════════
# LLM prompt
# ══════════════════════════════════════════════════════════════════════════════

_EXPANSION_PROMPT_AR = """\
أنت خبير في البحث والاسترجاع. مهمتك توليد صياغات بديلة للسؤال التالي
تحافظ على نفس المعنى لكن تستخدم مفردات مختلفة.

القواعد:
- أنتج ثلاثة إلى أربعة صياغات فقط.
- استخدم مرادفات ولغة مختلفة، ولكن لا تغير المعنى.
- اكتب كل صياغة في سطر مستقل.
- لا تضف أي شرح أو ترقيم، فقط الصياغات.

السؤال الأصلي: {query}

الصياغات البديلة:"""

_EXPANSION_PROMPT_EN = """\
You are an expert in search and retrieval. Your task is to generate alternative
phrasings of the following query that preserve its meaning but use different
vocabulary.

Rules:
- Produce three to four variants only.
- Use synonyms and different phrasing, do not change the meaning.
- Write each variant on its own line.
- Output variants only — no numbering, no explanation.

Original query: {query}

Alternative phrasings:"""


def _detect_language(text: str) -> str:
    """Simple heuristic: >30 % Arabic Unicode chars → 'ar', else 'en'."""
    arabic = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
    return "ar" if arabic / max(len(text), 1) > 0.3 else "en"


def _parse_llm_variants(raw: str, original: str, max_variants: int) -> List[str]:
    """
    Parse the raw LLM output into a clean list of query strings.
    """
    lines = [l.strip() for l in raw.splitlines() if l.strip()]
    # Strip leading bullets / numbers: "1. query" or "- query"
    cleaned = [re.sub(r'^[\-\d\.\)\•]+\s*', '', l) for l in lines]
    # Remove duplicates and the original
    seen = {original.lower()}
    variants: List[str] = [original]
    for q in cleaned:
        if q and q.lower() not in seen:
            variants.append(q)
            seen.add(q.lower())
        if len(variants) >= max_variants + 1:
            break
    return variants


# ══════════════════════════════════════════════════════════════════════════════
# Public class
# ══════════════════════════════════════════════════════════════════════════════

class QueryExpander:
    """
    Smart query expander that combines LLM rephrasing with a synonym table.

    Args:
        llm:              Any object with a ``.generate(prompt) -> str`` method.
                          Pass ``None`` to use the synonym table only.
        max_variants:     Maximum number of alternative queries to generate
                          (excluding the original). Default: 3.
        use_llm:          Whether to attempt LLM expansion first. Default: True.
        fallback_synonyms: Whether to use the synonym table when LLM fails.
                           Default: True.

    Example::

        expander = QueryExpander(llm=my_llm)
        queries  = expander.expand("رقم التليفون")
        # → ["رقم التليفون", "رقم الهاتف", "رقم الجوال", ...]
    """

    def __init__(
        self,
        llm: Optional[Any] = None,
        max_variants: int = 3,
        use_llm: bool = True,
        fallback_synonyms: bool = True,
    ) -> None:
        self.llm = llm
        self.max_variants = max_variants
        self.use_llm = use_llm and (llm is not None)
        self.fallback_synonyms = fallback_synonyms

        _mode = "LLM + synonyms" if self.use_llm else "synonyms only"
        logger.debug("QueryExpander initialised | mode=%s | max_variants=%d", _mode, max_variants)

    # ── Public ────────────────────────────────────────────────────────────

    def expand(self, query: str) -> List[str]:
        """
        Return [original_query, variant1, variant2, ...].
        Always returns at least the original query.
        """
        if not query or not query.strip():
            return [query]

        if self.use_llm:
            try:
                return self._llm_expand(query)
            except Exception as exc:
                logger.warning(
                    "LLM query expansion failed (%s) — falling back to synonym table",
                    exc,
                )

        if self.fallback_synonyms:
            variants = _build_synonym_variants(query)
            logger.debug(
                "Synonym expansion | query=%r | variants=%d", query, len(variants) - 1
            )
            return variants[: self.max_variants + 1]

        return [query]

    # ── Internal ──────────────────────────────────────────────────────────

    def _llm_expand(self, query: str) -> List[str]:
        """Call the LLM to generate semantically equivalent rephrasings."""
        lang = _detect_language(query)
        prompt_tpl = _EXPANSION_PROMPT_AR if lang == "ar" else _EXPANSION_PROMPT_EN
        prompt = prompt_tpl.format(query=query)

        try:
            raw = self.llm.generate(prompt, max_tokens=300, temperature=0.3)
        except Exception as exc:
            raise QueryExpansionError(str(exc)) from exc

        variants = _parse_llm_variants(raw, query, self.max_variants)

        # Enrich with synonyms for any variant the LLM didn't think of
        if self.fallback_synonyms:
            synonym_variants = _build_synonym_variants(query)
            seen = {v.lower() for v in variants}
            for sv in synonym_variants[1:]:            # skip original
                if sv.lower() not in seen and len(variants) <= self.max_variants:
                    variants.append(sv)
                    seen.add(sv.lower())

        logger.info(
            "LLM query expansion | original=%r | generated %d variants",
            query,
            len(variants) - 1,
        )
        return variants


# ══════════════════════════════════════════════════════════════════════════════
# Merge helper used by RAGSystem
# ══════════════════════════════════════════════════════════════════════════════

def merge_retrieval_results(
    results_per_query: List[List[Tuple[Any, float]]],
    top_k: int,
) -> List[Tuple[Any, float]]:
    """
    Merge results from multiple queries, keeping the highest score per chunk.

    Args:
        results_per_query: List of (chunk, score) lists, one per query variant.
        top_k:             Maximum number of results to return.

    Returns:
        Deduplicated, score-sorted list of (chunk, score) tuples.
    """
    best: Dict[str, Tuple[Any, float]] = {}

    for results in results_per_query:
        for chunk, score in results:
            cid = (
                getattr(chunk, "chunk_id", None)
                or getattr(chunk, "id", None)
                or str(chunk)
            )
            if cid not in best or score > best[cid][1]:
                best[cid] = (chunk, score)

    merged = sorted(best.values(), key=lambda x: x[1], reverse=True)

    if len(merged) > top_k:
        logger.debug(
            "merge_retrieval_results: trimmed %d → %d results", len(merged), top_k
        )

    return merged[:top_k]