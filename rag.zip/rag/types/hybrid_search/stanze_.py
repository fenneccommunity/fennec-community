import logging
from typing import List
import re

logger = logging.getLogger(__name__)


try:
    import stanza
    STANZA_AVAILABLE = True
except ImportError:
    STANZA_AVAILABLE = False
    logger.warning("Stanza is not installed. Simple entity extraction will be used instead")




class StanzaTokenizer:
    """
    Tokenizer using Stanza library
    """
    
    def __init__(self, language: str = 'ar', use_lemmatization: bool = True):
        """
        Initialize Stanza tokenizer
        
        Args:
            language: Language ('ar' for Arabic, 'en' for English)
            use_lemmatization:  Use lemmatization
        """
        self.language = language
        self.use_lemmatization = use_lemmatization
        self.nlp = None
        
        if STANZA_AVAILABLE:
            try:
                logger.info(f"🔄 Loading Stanza model ({language})...")
                
                # تحديد المعالجات المطلوبة
                # Determine required processors
                processors = 'tokenize'
                if use_lemmatization:
                    processors += ',mwt,pos,lemma'  # mwt للغة العربية، lemma للتجذير
                
                self.nlp = stanza.Pipeline(
                    language,
                    processors=processors,
                    verbose=False,
                    download_method=None,
                    use_gpu=False  # استخدام CPU للتوافق
                )
                logger.info("✅ Stanza loaded successfully")
                
            except Exception as e:
                logger.warning(f"⚠️ Failed to load Stanza: {e}")
                logger.warning("Simple tokenization will be used")
                self.nlp = None
        else:
            logger.warning("⚠️ Stanza is not available. For better accuracy, install it:")
            logger.warning("pip install stanza")
            logger.warning("python -c 'import stanza; stanza.download(\"ar\")'")
    
    def tokenize(self, text: str) -> List[str]:
        """
        Tokenize text using Stanza
        
        Args:
            text: Text to tokenize
            
        Returns:
           List of tokens
        """
        if not text or not text.strip():
            return []
        
        # إذا كان Stanza متاحاً، استخدمه
        # If Stanza is available, use it
        if self.nlp is not None:
            try:
                doc = self.nlp(text)
                tokens = []
                
                for sentence in doc.sentences:
                    for word in sentence.words:
                        # استخدام التجذير إذا كان مفعلاً
                        # Use lemmatization if enabled
                        if self.use_lemmatization and hasattr(word, 'lemma'):
                            token = word.lemma
                        else:
                            token = word.text
                        
                        # تنظيف الكلمة
                        # Clean token
                        token = token.strip()
                        if token and len(token) > 1:  # تجاهل الكلمات من حرف واحد
                            tokens.append(token.lower())
                
                return tokens
                
            except Exception as e:
                logger.warning(f"⚠️ Stanza error, using simple tokenization: {e}")
                return self._simple_tokenize(text)
        
        # التحليل البسيط كبديل
        # Simple tokenization as fallback
        return self._simple_tokenize(text)
    
    def _simple_tokenize(self, text: str) -> List[str]:
        """
        Simple tokenization fallback
        
        Args:
            text: النص | Text
            
        Returns:
            قائمة الكلمات | List of tokens
        """
        # إزالة الرموز والأرقام
        # Remove symbols and numbers
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\d+', '', text)
        
        # تقسيم إلى كلمات
        # Split into words
        tokens = text.lower().split()
        
        # تصفية الكلمات القصيرة
        # Filter short words
        tokens = [t for t in tokens if len(t) > 1]
        
        return tokens
    
    def tokenize_batch(self, texts: List[str]) -> List[List[str]]:
        """
        Tokenize a batch of texts
        
        Args:
            texts:  List of texts
            
        Returns:
            List of token lists
        """
        return [self.tokenize(text) for text in texts]
