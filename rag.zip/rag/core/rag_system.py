# -*- coding: utf-8 -*-

from __future__ import annotations
import asyncio, hashlib, inspect, json, time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Union
from .logger import get_logger
from .exceptions import (
     RAGInitializationError,
    RAGRetrievalError, VectorDBPersistenceError,
)
from .base_rag_system import BaseRAGSystem
from .prompt_router import PromptRouter
from .rag_config import RAGConfig
from .reranker import Reranker, RerankerConfig, RerankMode
from .query_expansion import QueryExpander, merge_retrieval_results
from .retrieval_cache import RetrievalCache

logger = get_logger(__name__)
PromptInput = Union[Any, Callable[[str, str], str], str]


@dataclass
class LoadedDocument:
    """
    A single document ready to be ingested by RAGSystem.
    Attributes:
        page_content: Raw text content.
        metadata:     Arbitrary key-value metadata.
        doc_id:       Unique ID — auto-generated if omitted.
    """
    page_content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    doc_id: Optional[str] = None

    def __post_init__(self) -> None:
        if not self.doc_id:
            h = hashlib.md5(self.page_content.encode()).hexdigest()[:8]
            self.doc_id = f"doc_{h}_{int(time.time())}"

    def to_dict(self) -> Dict[str, Any]:
        return {"doc_id": self.doc_id, "page_content": self.page_content,
                "metadata": self.metadata}

    def __repr__(self) -> str:
        preview = self.page_content[:80].replace("\n", " ")
        return f"LoadedDocument(doc_id={self.doc_id!r}, preview={preview!r}...)"


class RAGSystem(BaseRAGSystem):
    """
    External dependencies:
        vector_db:       .add(chunks), .search(query, top_k, score_threshold)
        llm:             .generate(prompt) -> str
        chunker:         .chunk_text(text, doc_id)  OR  .chunk(text, doc_id)
        context_manager: .build(query, chunks) -> str
    """

    def __init__(
        self,
        vector_db: Any,
        llm: Any,
        chunker: Any,
        context_manager: Any,
        config: Optional[RAGConfig] = None,
        prompt: Optional[PromptInput] = None,
        enable_query_expansion: bool = True,
        query_expansion_variants: int = 3,
    ) -> None:
        """
        Initialise RAGSystem.

        Args:
            vector_db:                 Vector database instance.
            llm:                       Language model instance.
            chunker:                   Text chunker instance.
            context_manager:           Context builder instance.
            config:                    RAGConfig — defaults applied if None.
            prompt:                    Custom prompt (PromptTemplate | callable | str).
                                       None => PromptRouter / built-in default.
            enable_query_expansion:    Expand queries with LLM + synonyms. Default True.
            query_expansion_variants:  Max alternative queries generated. Default 3.

        Raises:
            RAGInitializationError: If a required component is None.
        """
        super().__init__(config)

        missing = [n for n, o in [("vector_db", vector_db), ("llm", llm),
                                   ("chunker", chunker), ("context_manager", context_manager)]
                   if o is None]
        if missing:
            raise RAGInitializationError(
                f"Required components are None: {', '.join(missing)}")

        self.vector_db       = vector_db
        self.llm             = llm
        self.chunker         = chunker
        self.context_manager = context_manager

        self._custom_prompt: Optional[PromptInput] = prompt

        self.prompt_router: Optional[PromptRouter] = (
            PromptRouter(include_few_shot=self.config.include_few_shot)
            if (self.config.enable_prompt_routing and prompt is None) else None
        )

        self.reranker: Optional[Reranker] = None
        if self.config.enable_reranking:
            rc = RerankerConfig(
                mode=RerankMode(self.config.rerank_mode),
                top_k=self.config.rerank_top_k,
                original_score_weight=self.config.rerank_original_weight,
                llm_score_weight=self.config.rerank_llm_weight,
                diversity_weight=self.config.rerank_diversity_weight,
                length_weight=self.config.rerank_length_weight,
            )
            self.reranker = Reranker(config=rc, llm=self.llm)

        self._query_expander: Optional[QueryExpander] = (
            QueryExpander(llm=self.llm, max_variants=query_expansion_variants,
                          use_llm=True, fallback_synonyms=True)
            if enable_query_expansion else None
        )

        # ── Retrieval cache ──────────────────────────────────────────────────
        self._retrieval_cache: RetrievalCache | None = (
            RetrievalCache(
                maxsize=self.config.cache_maxsize,
                ttl=self.config.cache_ttl if self.config.cache_ttl > 0 else None,
            )
            if self.config.enable_retrieval_cache else None
        )

        logger.info(
            "RAGSystem initialised | reranking=%s | routing=%s | expansion=%s | cache=%s",
            self.config.enable_reranking,
            self.config.enable_prompt_routing,
            enable_query_expansion,
            self._retrieval_cache is not None,
        )

    # ------------------------------------------------------------------
    # Friendly API — helpers for common use-cases
    # ------------------------------------------------------------------

    def add_text(self, text: str, doc_id: Optional[str] = None,
                 metadata: Optional[Dict[str, Any]] = None) -> int:
        """
        Add a single plain-text string directly.
        أضف نصاً واحداً مباشرةً بدون تغليف.

        Args:
            text:     Text to index.
            doc_id:   Optional ID (auto-generated if omitted).
            metadata: Optional metadata dict.

        Returns:
            Number of chunks created.

        Example::

            n = rag.add_text("اسم: محمد, الهاتف: 050...", doc_id="emp_1")
            print(f"Created {n} chunks")
        """
        doc = LoadedDocument(
            page_content=text,
            doc_id=doc_id or f"text_{int(time.time())}",
            metadata=metadata or {},
        )
        return self.add_documents([doc]).get(doc.doc_id, 0)

    def add_texts(self, texts: Dict[str, str],
                  metadata: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, int]:
        """
        Add multiple texts from a {doc_id: text} dict.

        Args:
            texts:    {doc_id: text} mapping.
            metadata: Optional {doc_id: metadata_dict}.

        Returns:
            {doc_id: num_chunks}.

        Example::

            rag.add_texts({
                "emp_1": "الاسم: أحمد, الهاتف: 055...",
                "emp_2": "الاسم: سارة, الهاتف: 050...",
            })
        """
        meta = metadata or {}
        docs = [LoadedDocument(page_content=t, doc_id=did, metadata=meta.get(did, {}))
                for did, t in texts.items()]
        return self.add_documents(docs)

    def ask(self, question: str, include_sources: bool = False,
            language: Optional[str] = None, **llm_kwargs: Any) -> str:
        """
        Friendly alias for generate().
        Example::

            answer = rag.ask("ما رقم هاتف محمد؟")
        """
        return self.generate(question, include_sources=include_sources,
                             language=language, **llm_kwargs)

    # ------------------------------------------------------------------
    # Document ingestion
    # ------------------------------------------------------------------

    def add_documents(self, docs: List[LoadedDocument]) -> Dict[str, int]:
        """
        Chunk and index a list of LoadedDocument objects.

        Args:
            docs: List of LoadedDocument.

        Returns:
            {doc_id: num_chunks} — 0 for failed/empty documents.
        """
        if not docs:
            logger.warning("add_documents | empty list — nothing to do")
            return {}

        logger.info("add_documents | documents=%d", len(docs))
        results: Dict[str, int] = {}
        all_chunks: List[Any] = []

        for doc in docs:
            did = doc.doc_id or "unknown"
            if not doc.page_content or not doc.page_content.strip():
                logger.warning("Skipping empty document | doc_id=%s", did)
                results[did] = 0
                continue
            try:
                fn = (self.chunker.chunk_text
                      if hasattr(self.chunker, "chunk_text")
                      else self.chunker.chunk)
                chunks = fn(doc.page_content, did)
                all_chunks.extend(chunks)
                results[did] = len(chunks)
                logger.debug("Chunked | doc_id=%s | chunks=%d", did, len(chunks))
            except Exception as exc:
                logger.error("Chunking failed | doc_id=%s | reason=%s", did, exc)
                results[did] = 0

        if all_chunks:
            try:
                self.vector_db.add(all_chunks)
                ok = sum(1 for v in results.values() if v > 0)
                self.stats["total_documents"] += ok
                self.stats["total_chunks"]    += len(all_chunks)
                logger.info("Indexed | docs=%d | chunks=%d", ok, len(all_chunks))
                # مسح الكاش عند إضافة مستندات جديدة
                # Clear cache when new documents are indexed
                if self._retrieval_cache is not None:
                    self._retrieval_cache.clear()
                    logger.debug("RetrievalCache cleared after new doc ingestion")
            except Exception as exc:
                logger.error("VectorDB write failed | reason=%s", exc)
                raise

        return results

    # ------------------------------------------------------------------
    # Retrieval with smart query expansion
    # ------------------------------------------------------------------

    def retrieve(self, query: str,
                 top_k: Optional[int] = None) -> List[Tuple[Any, float]]:
        """
        Retrieve relevant chunks using smart query expansion.

        Strategy:
          1. Expand query → semantically equivalent variants (LLM + synonyms).
          2. Search vector DB for each variant.
          3. Merge results — keep highest score per unique chunk.
          4. Optionally rerank.

        Args:
            query: User question.
            top_k: Override configured top_k.

        Returns:
            [(chunk, score)] sorted by score descending.

        Raises:
            RAGRetrievalError: On unexpected search failure.
        """
        if not query or not query.strip():
            logger.warning("retrieve | empty query")
            return []

        k = top_k if top_k is not None else self.config.top_k

        # ── Cache lookup ─────────────────────────────────────────────────────
        if self._retrieval_cache is not None:
            cached = self._retrieval_cache.get(query, k)
            if cached is not None:
                logger.debug("retrieve | CACHE HIT | query=%r", query[:60])
                return cached

        try:
            variants = (self._query_expander.expand(query)
                        if self._query_expander else [query])
            logger.debug("Query variants | total=%d | %s", len(variants), variants)

            per_variant = []
            for v in variants:
                res = self.vector_db.search(
                    v, top_k=k, score_threshold=self.config.min_score)
                per_variant.append(res)
                logger.debug("Search | variant=%r | hits=%d", v, len(res))

            results = (merge_retrieval_results(per_variant, top_k=k)
                       if len(variants) > 1 else per_variant[0])

            logger.info("retrieve | query=%r | chunks=%d", query[:60], len(results))

            if self.reranker and results:
                results = self.reranker.rerank(query=query, chunks=results)
                logger.debug("Reranked | top_score=%.3f",
                             results[0][1] if results else 0.0)

            # ── Cache store ──────────────────────────────────────────────────
            if self._retrieval_cache is not None and results:
                self._retrieval_cache.set(query, k, results)

            return results

        except Exception as exc:
            logger.error("Retrieval error | query=%r | reason=%s", query[:60], exc)
            raise RAGRetrievalError(query=query, reason=str(exc)) from exc

    # ------------------------------------------------------------------
    # Generation
    # ------------------------------------------------------------------

    def generate(self, query: str, include_sources: bool = False,
                 language: Optional[str] = None, **llm_kwargs: Any) -> str:
        """
        End-to-end RAG: retrieve -> context -> answer.

        Args:
            query:           User question.
            include_sources: Append source IDs to the answer.
            language:        "ar" or "en" — auto-detected if None.
            **llm_kwargs:    Extra kwargs for llm.generate().

        Returns:
            Answer string. Never raises — errors returned as readable strings.
        """
        self.stats["total_queries"] += 1

        if not query or not query.strip():
            return "⚠️ Please enter a valid question."

        try:
            retrieved = self.retrieve(query)

            if not retrieved:
                self.stats["failed_queries"] += 1
                logger.info("No results | query=%r", query[:60])
                return (" No relevant information found.")

            context = self.context_manager.build(query, retrieved)
            prompt  = self._resolve_prompt(query, context, language)
            answer: str = self.llm.generate(prompt, **llm_kwargs)

            if include_sources:
                answer = f"{answer}\n\n{self._format_sources(retrieved)}"

            self.stats["successful_queries"] += 1
            logger.info("Answer generated | query=%r", query[:60])
            return answer

        except RAGRetrievalError:
            self.stats["failed_queries"] += 1
            return "❌ Search error occurred."

        except Exception as exc:
            self.stats["failed_queries"] += 1
            logger.error("Generation error | query=%r | reason=%s", query[:60], exc)
            return f"❌ There was an error: {exc}"

    # ------------------------------------------------------------------
    # Prompt management
    # ------------------------------------------------------------------

    def set_prompt(self, prompt: Optional[PromptInput]) -> None:
        """
        Replace or remove the custom prompt after initialisation.
        Args:
            prompt: PromptTemplate | callable | str
                    OR None to restore PromptRouter / built-in default.

        Example::

            tpl = PromptTemplate(
                template="Context:\n{context}\n\nQ: {question}\nA:",
            )
            rag.set_prompt(tpl)

            # Restore default
            rag.set_prompt(None)
        """
        self._custom_prompt = prompt
        if prompt is None and self.config.enable_prompt_routing:
            self.prompt_router = PromptRouter(
                include_few_shot=self.config.include_few_shot)
            logger.info("set_prompt | custom removed — PromptRouter restored")
        else:
            self.prompt_router = None
            logger.info("set_prompt | type=%s", type(prompt).__name__)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_prompt(self, query: str, context: str,
                        language: Optional[str] = None) -> str:
        """Priority: custom > PromptRouter > built-in default."""
        if self._custom_prompt is not None:
            cp = self._custom_prompt
            if hasattr(cp, "format"):
                try:
                    return cp.format(context=context, question=query)
                except (KeyError, TypeError):
                    return cp.format(context=context, query=query)
            if callable(cp):
                return cp(context, query)
            if isinstance(cp, str):
                return cp.format(context=context, question=query)
            logger.warning("Unknown prompt type %s — using default", type(cp))

        if self.prompt_router:
            lang  = language or None
            built = self.prompt_router.build(query=query, context=context, language=lang)
            det   = self.prompt_router.detect_language(query) if lang is None else lang
            qtype = self.prompt_router.detect_question_type(query, det)
            logger.debug("PromptRouter | lang=%s | type=%s", det, qtype.value)
            return built

        lang = language or self._detect_language_simple(query)
        return self._build_prompt(query, context, language_pr=lang)

    def _detect_language_simple(self, text: str) -> str:
        return "ar" if any("\u0600" <= c <= "\u06FF" for c in text) else "en"

    def _build_prompt(self, query: str, context: str, language_pr: str) -> str:
        if language_pr == "ar":
            return (
                "أنت مساعد ذكي متخصص في الإجابة على الأسئلة بدقة.\n"
                "استخدم المعلومات التالية للإجابة بدقة ووضوح.\n\n"
                "القواعد:\n"
                "• أجب بناءً على المعلومات المقدمة فقط\n"
                "• كن دقيقاً ومختصراً\n"
                "• إذا لم تجد المعلومات الكافية قل: «لا توجد معلومات كافية»\n"
                "• أجب بنفس لغة السؤال\n"
                f"\nالمعلومات:\n{context}\n\nالسؤال: {query}\nالإجابة:"
            )
        return (
            "You are an intelligent assistant specialised in accurate QA.\n"
            "Use the following information to answer accurately and concisely.\n\n"
            "Rules:\n"
            "• Answer based only on the provided information\n"
            "• Be accurate and concise\n"
            "• If information is insufficient say: 'Insufficient information to answer'\n"
            "• Answer in the same language as the question\n"
            f"\nAvailable Information:\n{context}\n\nQuestion: {query}\nAnswer:"
        )

    def _format_sources(self, chunks: List[Tuple[Any, float]],
                        max_sources: int = 3) -> str:
        seen: set = set()
        lines: List[str] = []
        for chunk, score in chunks:
            did = (getattr(chunk, "doc_id", None)
                   or getattr(chunk, "document_id", "unknown"))
            if did in seen:
                continue
            seen.add(did)
            lines.append(f"• {did}  (score: {score:.2f})")
            if len(lines) >= max_sources:
                break
        return ("📚 Sources:\n" + "\n".join(lines)) if lines else ""

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def remove_document(self, doc_id: str) -> int:
        """Remove all chunks of a document from the vector DB."""
        try:
            removed = self.vector_db.remove_by_doc_id(doc_id)
            if removed > 0:
                self.stats["total_documents"] = max(0, self.stats["total_documents"] - 1)
                self.stats["total_chunks"]    = max(0, self.stats["total_chunks"] - removed)
                logger.info("Removed | doc_id=%s | chunks=%d", doc_id, removed)
            else:
                logger.warning("Not found for removal | doc_id=%s", doc_id)
            return removed
        except Exception as exc:
            logger.error("Remove failed | doc_id=%s | reason=%s", doc_id, exc)
            return 0

    def save(self, path: str) -> None:
        """Save vector DB + stats to directory."""
        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        try:
            self.vector_db.save(p / "vector_db")
            with open(p / "stats.json", "w", encoding="utf-8") as f:
                json.dump(self.stats, f, indent=2, ensure_ascii=False)
            logger.info("Saved | path=%s", p)
        except Exception as exc:
            logger.error("Save failed | path=%s | reason=%s", p, exc)
            raise VectorDBPersistenceError("save", str(p), str(exc)) from exc

    @classmethod
    def load(cls, path: str, vector_db: Any, llm: Any, chunker: Any,
             context_manager: Any, config: Optional[RAGConfig] = None,
             enable_query_expansion: bool = True) -> "RAGSystem":
        """Load a previously saved RAG system."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Saved RAGSystem not found: {p}")
        try:
            vector_db.load(p / "vector_db")
        except Exception as exc:
            raise VectorDBPersistenceError("load", str(p), str(exc)) from exc
        system = cls(vector_db=vector_db, llm=llm, chunker=chunker,
                     context_manager=context_manager, config=config,
                     enable_query_expansion=enable_query_expansion)
        sf = p / "stats.json"
        if sf.exists():
            with open(sf, encoding="utf-8") as f:
                system.stats.update(json.load(f))
        logger.info("Loaded | path=%s", p)
        return system

    # ------------------------------------------------------------------
    # Stats & representation
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------

    def invalidate_cache(self) -> None:
        """
        Manually clear the retrieval cache.
        Useful when documents are updated externally.
        """
        if self._retrieval_cache is not None:
            self._retrieval_cache.clear()
            logger.info("RetrievalCache manually cleared")

    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Retrieval cache statistics.

        Returns:
            dict with keys: size, maxsize, ttl, hits, misses, hit_rate.
            Empty dict if cache is disabled.
        """
        if self._retrieval_cache is None:
            return {}
        return self._retrieval_cache.stats()

    def get_stats(self) -> Dict[str, Any]:
        return {
            **super().get_stats(),
            "vector_db_size":  getattr(self.vector_db, "size", 0),
            "llm_type":        type(self.llm).__name__,
            "chunker_type":    type(self.chunker).__name__,
            "query_expansion": self._query_expander is not None,
            "reranking":       self.reranker is not None,
            "cache":           self.get_cache_stats(),
        }

    def __repr__(self) -> str:
        return (
            f"RAGSystem("
            f"docs={self.stats.get('total_documents', 0)}, "
            f"chunks={self.stats.get('total_chunks', 0)}, "
            f"queries={self.stats.get('total_queries', 0)}, "
            f"expansion={self._query_expander is not None})"
        )

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def cleanup(self) -> None:
        for name in ("vector_db", "llm", "chunker", "context_manager"):
            comp = getattr(self, name, None)
            if comp and hasattr(comp, "cleanup"):
                try:
                    comp.cleanup()
                    logger.debug("Cleaned | component=%s", name)
                except Exception as exc:
                    logger.error("Cleanup error | component=%s | reason=%s", name, exc)
        logger.info("RAGSystem cleanup complete")

    def __enter__(self) -> "RAGSystem":
        return self

    def __exit__(self, *_: Any) -> bool:
        self.cleanup()
        return False

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def aadd_documents(self, docs: Dict[str, str]) -> Dict[str, int]:
        """Async document ingestion — chunks all docs concurrently."""
        if not docs:
            return {}
        results: Dict[str, int] = {}
        all_chunks: List[Any] = []

        async def _chunk_one(doc_id: str, text: str):
            if not text or not text.strip():
                return doc_id, []
            try:
                fn = (self.chunker.chunk_text
                      if hasattr(self.chunker, "chunk_text")
                      else self.chunker.chunk)
                chunks = await asyncio.to_thread(fn, text, doc_id)
                return doc_id, chunks
            except Exception as exc:
                logger.error("Async chunk | doc_id=%s | reason=%s", doc_id, exc)
                return doc_id, []

        for did, chunks in await asyncio.gather(
                *[_chunk_one(d, t) for d, t in docs.items()]):
            results[did] = len(chunks)
            all_chunks.extend(chunks)

        if all_chunks:
            adder = getattr(self.vector_db, "aadd", None)
            await (adder(all_chunks) if adder
                   else asyncio.to_thread(self.vector_db.add, all_chunks))
            self.stats["total_documents"] += sum(1 for v in results.values() if v > 0)
            self.stats["total_chunks"]    += len(all_chunks)
        return results

    async def aretrieve(self, query: str,
                        top_k: Optional[int] = None) -> List[Tuple]:
        """Async retrieval with query expansion."""
        if not query or not query.strip():
            return []
        k = top_k if top_k is not None else self.config.top_k
        variants = (await asyncio.to_thread(self._query_expander.expand, query)
                    if self._query_expander else [query])

        async def _search(v: str):
            fn = getattr(self.vector_db, "asearch", None)
            if fn:
                return await fn(v, top_k=k, score_threshold=self.config.min_score)
            return await asyncio.to_thread(
                self.vector_db.search, v, top_k=k,
                score_threshold=self.config.min_score)

        per_variant = list(await asyncio.gather(*[_search(v) for v in variants]))
        results = (merge_retrieval_results(per_variant, top_k=k)
                   if len(variants) > 1 else per_variant[0])
        if self.reranker and results:
            results = await asyncio.to_thread(
                self.reranker.rerank, query=query, chunks=results)
        return results

    async def agenerate(self, query: str, include_sources: bool = False,
                        language: Optional[str] = None, **llm_kwargs: Any) -> str:
        """Async end-to-end generation."""
        self.stats["total_queries"] += 1
        if not query or not query.strip():
            return "⚠️ Please enter a valid question."
        try:
            retrieved = await self.aretrieve(query)
            if not retrieved:
                self.stats["failed_queries"] += 1
                return "No relevant information found."
            context = await asyncio.to_thread(
                self.context_manager.build, query, retrieved)
            prompt = await asyncio.to_thread(
                self._resolve_prompt, query, context, language)
            gen_fn = getattr(self.llm, "generate_async", None)
            answer = (await gen_fn(prompt, **llm_kwargs) if gen_fn
                      else await asyncio.to_thread(self.llm.generate, prompt, **llm_kwargs))
            if include_sources:
                answer = f"{answer}\n\n{self._format_sources(retrieved)}"
            self.stats["successful_queries"] += 1
            return answer
        except Exception as exc:
            self.stats["failed_queries"] += 1
            logger.error("Async gen error | reason=%s", exc)
            return f"❌ Error: {exc}"

    async def astream(self, query: str, language: Optional[str] = None,
                      **llm_kwargs: Any):
        """Async streaming generation — yields tokens."""
        retrieved = await self.aretrieve(query)
        if not retrieved:
            yield "No relevant information found."
            return
        context = await asyncio.to_thread(
            self.context_manager.build, query, retrieved)
        prompt = await asyncio.to_thread(
            self._resolve_prompt, query, context, language)
        result = self.llm.astream(prompt, **llm_kwargs)
        if inspect.isasyncgen(result):
            async for token in result:
                yield token
        elif inspect.iscoroutine(result):
            actual = await result
            if inspect.isasyncgen(actual):
                async for token in actual:
                    yield token
            elif isinstance(actual, str):
                for word in actual.split():
                    yield word + " "
                    await asyncio.sleep(0)
            else:
                yield str(actual)
        elif hasattr(result, "__iter__"):
            for token in result:
                yield str(token)
                await asyncio.sleep(0)
        else:
            yield str(result)

    async def __aenter__(self) -> "RAGSystem":
        return self

    async def __aexit__(self, *_: Any) -> bool:
        self.cleanup()
        return False