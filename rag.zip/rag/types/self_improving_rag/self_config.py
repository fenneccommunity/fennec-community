from dataclasses import dataclass,field
from typing import List

@dataclass
class SelfRAGConfig:
    """
    Configuration for Self-RAG.

    Attributes:
        max_refinement_iterations: Hard cap on refinement cycles.
        confidence_threshold:      Stop iterating when confidence >= this value.
        enable_answer_refinement:  Whether to rewrite the answer each cycle.
        enable_retrieval_refinement: Whether to adapt the retrieval query.
        llm_retries:               Retries for each LLM call.
        fast_mode:                 When True, generate + evaluate in one LLM call
                                   (saves ~50% LLM calls per iteration).
        skip_refinement_on_high_confidence: When True and first answer meets
                                   confidence_threshold, skip all refinement.
    """
    max_refinement_iterations: int = 3
    confidence_threshold: float = 0.80
    enable_answer_refinement: bool = True
    enable_retrieval_refinement: bool = True
    llm_retries: int = 2
    fast_mode: bool = True
    skip_refinement_on_high_confidence: bool = True

@dataclass
class RecursiveRAGConfig:              # هذا الإعداد يتحكم في تفكيك الأسئلة المعقده إلى أسئلة فرعية أصغر:
    """
    Configuration for Recursive RAG.

    Attributes:
        max_depth:           Maximum recursion depth (prevents infinite loops).
        max_sub_questions:   Cap on sub-questions per decomposition.
        min_query_length:    Queries shorter than this are never decomposed.
        complexity_keywords: Arabic/English markers that signal complexity.
        llm_retries:         Retries for each LLM call.
    """
    max_depth: int = 3
    max_sub_questions: int = 4
    min_query_length: int = 40
    complexity_keywords: List[str] = field(default_factory=lambda: [
        "و", "أو", "ثم", "بعد", "قبل", "أسباب", "نتائج", "مقارنة",
        "الفرق", "العلاقة", "التأثير", "كيف", "لماذا", "متى", "أين",
        "and", "or", "causes", "effects", "compare", "difference",
        "relationship", "impact", "how", "why", "when",
    ])
    llm_retries: int = 2

# تفكيك السؤال المعقد إلى أسئلة فرعية أصغر:
_DECOMPOSE_PROMPT = """\
                        Break the complex question below into {max_sub} simpler, self-contained sub-questions.
                        Return ONLY a JSON array of strings, no extra text.

                        Question: {query}

                        Example output: ["sub-question 1", "sub-question 2", "sub-question 3"]

                        JSON array:"""

# دمج الإجابات الجزئية في إجابة شاملة واحدة:
_MERGE_PROMPT = """\
                        Synthesise the sub-answers below into a single, comprehensive, coherent answer to the original question.

                        Original question: {query}

                        Sub-answers:
                        {sub_answers}

                        Comprehensive answer:"""



_EVAL_PROMPT_TEMPLATE = """\
                        You are a critical evaluator. Evaluate the answer below and return a JSON object only.

                        Question: {query}

                        Answer: {answer}

                        Context:
                        {context}

                        Return ONLY valid JSON matching this schema (all scores 0.0–1.0):
                        {{
                        "relevance": <float>,
                        "accuracy": <float>,
                        "completeness": <float>,
                        "clarity": <float>,
                        "issues": [<string>, ...],
                        "suggestions": [<string>, ...]
                        }}"""


# Fast mode: generate + evaluate in a single LLM call
_FAST_PROMPT_TEMPLATE = """\
أنت مساعد ذكي ومُقيِّم. اقرأ السياق التالي ثم:
1. أجب على السؤال بدقة بناءً على السياق فقط.
2. قيّم إجابتك وأعد JSON للتقييم.

السياق:
{context}

السؤال: {query}

أعد الرد بالتنسيق التالي EXACTLY (لا تضف أي نص خارجه):
{{
  "answer": "<إجابتك الكاملة هنا>",
  "evaluation": {{
    "relevance": <0.0-1.0>,
    "accuracy": <0.0-1.0>,
    "completeness": <0.0-1.0>,
    "clarity": <0.0-1.0>,
    "issues": [],
    "suggestions": []
  }}
}}"""