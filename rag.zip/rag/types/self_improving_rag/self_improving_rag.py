from __future__ import annotations
import hashlib
import json
import logging
import time
import re
from typing import Any, Dict, List, Optional
from .self_config import SelfRAGConfig, _EVAL_PROMPT_TEMPLATE, _FAST_PROMPT_TEMPLATE
from .self_rag_dataclass import EvaluationResult, RefinementStep, SelfRAGResult

logging.basicConfig(
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("SelfImprovingRAG")
logger.setLevel(logging.INFO)


# ─────────────────────────────────────────────────────────────────────────────
# Exceptions  
# ─────────────────────────────────────────────────────────────────────────────

class RAGSystemError(Exception):
    """Base for all self-improving RAG errors."""


class LLMCallError(RAGSystemError):
    """Raised when every retry of an LLM call fails."""


class RetrievalError(RAGSystemError):
    """Raised when document retrieval fails."""


# ─────────────────────────────────────────────────────────────────────────────
# Helper utilities
# ─────────────────────────────────────────────────────────────────────────────

def _doc_key(doc: Dict[str, Any]) -> str:
    """Stable hash key for a document (first 120 chars of text)."""
    return hashlib.md5(doc.get("text", "")[:120].encode()).hexdigest()


def _deduplicate(docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove duplicate docs, keeping the copy with the highest score."""
    best: Dict[str, Dict[str, Any]] = {}
    for doc in docs:
        key = _doc_key(doc)
        if key not in best or doc.get("score", 0.0) > best[key].get("score", 0.0):
            best[key] = doc
    return list(best.values())


def _call_llm(llm: Any, prompt: str, retries: int = 2, backoff: float = 0.5) -> str:
    """
    Call ``llm.generate(prompt)`` with exponential back-off retries.

    Raises:
        LLMCallError: if every attempt fails.
    """
    last_exc: Exception = RuntimeError("no attempts made")
    for attempt in range(retries + 1):
        try:
            return llm.generate(prompt).strip()
        except Exception as exc:
            last_exc = exc
            if attempt < retries:
                wait = backoff * (2 ** attempt)
                logger.warning(
                    "LLM call failed (attempt %d): %s – retrying in %.1fs",
                    attempt + 1, exc, wait,
                )
                time.sleep(wait)
    raise LLMCallError(
        f"LLM call failed after {retries + 1} attempts: {last_exc}"
    ) from last_exc


def _retrieve_safe(rag_system: Any, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
    """
    Retrieve documents and normalise ANY backend output format to List[Dict].
    Handles:
    - List[Tuple[DocumentChunk, float]]  ← FAISS / RAGSystem.retrieve()
    - List[Dict]                         ← already normalised
    - {"results": [...]}                 ← wrapped dict
    """
    try:
        raw = rag_system.retrieve(query, top_k=top_k)
    except Exception as exc:
        raise RetrievalError(f"retrieve() raised: {exc}") from exc

    if isinstance(raw, dict):
        raw = raw.get("results", [])

    if not isinstance(raw, list):
        return []

    normalised: List[Dict[str, Any]] = []
    for item in raw:
        # Tuple[DocumentChunk, float] — returned by FAISSVectorDatabase
        if isinstance(item, tuple) and len(item) == 2:
            chunk, score = item
            text   = getattr(chunk, "text", None) or getattr(chunk, "page_content", None) or ""
            source = getattr(chunk, "chunk_id", None) or getattr(chunk, "doc_id", None) or ""
            normalised.append({
                "text":     text,
                "score":    float(score),
                "source":   str(source),
                "metadata": getattr(chunk, "metadata", {}),
            })
        elif isinstance(item, dict):
            normalised.append(item)
        elif hasattr(item, "text"):
            normalised.append({
                "text":   getattr(item, "text", ""),
                "score":  float(getattr(item, "score", 0.0)),
                "source": str(getattr(item, "chunk_id", getattr(item, "doc_id", ""))),
            })
    return normalised


# ─────────────────────────────────────────────────────────────────────────────
# Main class
# ─────────────────────────────────────────────────────────────────────────────

class SelfIRAG:
    """
    Self-RAG: iteratively retrieves, generates, evaluates, and refines.
    The loop continues until ``confidence_threshold`` is met or
    ``max_refinement_iterations`` is exhausted.  The iteration with the
    highest confidence is returned.

    Example::

        cfg = SelfRAGConfig(max_refinement_iterations=3, confidence_threshold=0.85)
        rag = SelfIRAG(rag_system, llm, config=cfg)
        result = rag.query("ما هو الذكاء الاصطناعي؟")
        print(result.answer, result.confidence)
    """

    def __init__(
        self,
        rag_system: Any,
        llm: Any,
        config: Optional[SelfRAGConfig] = None,
    ) -> None:
        if not llm:
            raise ValueError("SelfRAG requires an LLM.")
        self.rag_system = rag_system
        self.llm = llm
        self.config = config or SelfRAGConfig()

    # ── Public API ────────────────────────────────────────────────────────

    def query(self, query: str, context: Optional[Dict[str, Any]] = None) -> SelfRAGResult:
        """
        Run the self-improvement loop and return the best answer found.\n

        Args:
            query:   Natural-language question.
            context: Optional extra context forwarded to the backend.

        Returns:
            :class:`SelfRAGResult` with answer, confidence, and iteration history.
        """
        logger.info("🔄 SelfRAG | query=%r", query[:80])
        history: List[RefinementStep] = []
        current_query = query

        for iteration in range(1, self.config.max_refinement_iterations + 1):
            # Retrieve
            docs = self._retrieve(current_query, history)

            if self.config.fast_mode:
                answer, evaluation = self._generate_and_evaluate_fast(query, docs)
            else:
                answer = self._generate(query, docs)
                evaluation = self._evaluate(query, answer, docs)

            step = RefinementStep(iteration=iteration, answer=answer, evaluation=evaluation)
            history.append(step)

            logger.info(
                "  iter=%d | confidence=%.3f (R=%.2f A=%.2f C=%.2f Cl=%.2f)",
                iteration, evaluation.confidence,
                evaluation.relevance, evaluation.accuracy,
                evaluation.completeness, evaluation.clarity,
            )

            if evaluation.confidence >= self.config.confidence_threshold:
                logger.info("✅ Confidence threshold met at iteration %d", iteration)
                break

            # Refine for next round
            if iteration < self.config.max_refinement_iterations:
                if self.config.enable_answer_refinement:
                    answer = self._refine_answer(query, answer, evaluation)
                    step.answer = answer

                if self.config.enable_retrieval_refinement and evaluation.suggestions:
                    current_query = self._adapt_query(query, evaluation.suggestions)

        best = max(history, key=lambda s: s.confidence)
        return SelfRAGResult(
            answer=best.answer,
            confidence=best.confidence,
            iterations=len(history),
            history=history,
        )

    def add_document(self, text: str, metadata: Optional[Dict[str, Any]] = None) -> Any:
        return self.rag_system.add_document(text, metadata or {})

    # ── Private Helpers ───────────────────────────────────────────────────

    def _retrieve(
        self,
        query: str,
        history: List[RefinementStep],  # kept for future use (e.g. avoid re-fetching same docs)
    ) -> List[Dict[str, Any]]:
        try:
            return _retrieve_safe(self.rag_system, query)
        except RetrievalError as exc:
            logger.error("❌ Retrieval failed: %s", exc)
            return []

    def _generate(self, query: str, docs: List[Dict[str, Any]]) -> str:
        """Generate an answer from retrieved docs."""
        if not docs:
            return "no documents found"

        context = "\n\n".join(
            d.get("text", "")
            for d in docs[:5]
            if d.get("text")
        )

        prompt = (
            "أنت مساعد ذكي متخصص في الإجابة على الأسئلة بدقة.\n\n"
            "استخدم المعلومات التالية للإجابة على السؤال بدقة ووضوح.\n\n"
            "القواعد المهمة:\n"
            "• أجب بناءً على المعلومات المقدمة فقط\n"
            "• كن دقيقاً ومختصراً\n"
            "• إذا لم تجد المعلومات الكافية، قل \"لا توجد معلومات كافية للإجابة\"\n"
            "• أجب بنفس اللغه الموجوده في السؤال\n\n"
            f"المعلومات المتاحة:\n{context}\n\n"
            f"السؤال: {query}\n"
            "الإجابة:"
        )

        try:
            return _call_llm(self.llm, prompt, retries=self.config.llm_retries)
        except LLMCallError as exc:
            logger.error("❌ Generation failed: %s", exc)
            return "error in generating answer"

    def _generate_and_evaluate_fast(
        self,
        query: str,
        docs: List[Dict[str, Any]],
    ) -> tuple[str, EvaluationResult]:
     
        if not docs:
            return "There is not enough information.", EvaluationResult()

        context = "\n\n".join(
            d.get("text", "")
            for d in docs[:5]
            if d.get("text")
        )

        prompt = _FAST_PROMPT_TEMPLATE.format(context=context, query=query)

        try:
            raw = _call_llm(self.llm, prompt, retries=self.config.llm_retries)
        except LLMCallError as exc:
            logger.error("❌ Fast generate+evaluate failed: %s", exc)
            return "error in generating answer", EvaluationResult()

        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        try:
            data = json.loads(clean)
            answer = data.get("answer", "").strip() or "not found enough docs"
            evaluation = self._parse_evaluation(json.dumps(data.get("evaluation", {})))
            return answer, evaluation
        except (json.JSONDecodeError, AttributeError):
            # Graceful degradation: fall back to slow path
            logger.warning("⚠ Fast mode JSON parse failed – falling back to two-step")
            answer = self._generate(query, docs)
            evaluation = self._evaluate(query, answer, docs)
            return answer, evaluation

    def _evaluate(
        self,
        query: str,
        answer: str,
        docs: List[Dict[str, Any]],
    ) -> EvaluationResult:
        context_text = "\n".join(d.get("text", "") for d in docs[:4])
        prompt = _EVAL_PROMPT_TEMPLATE.format(
            query=query, answer=answer, context=context_text
        )
        try:
            raw = _call_llm(self.llm, prompt, retries=self.config.llm_retries)
            return self._parse_evaluation(raw)
        except LLMCallError as exc:
            logger.warning("⚠ Evaluation LLM call failed: %s – using defaults", exc)
            return EvaluationResult()

    @staticmethod
    def _parse_evaluation(raw: str) -> EvaluationResult:
        """Parse JSON evaluation output; fall back gracefully."""
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        try:
            data = json.loads(clean)
        except json.JSONDecodeError:
            data = {}
            for key in ("relevance", "accuracy", "completeness", "clarity"):
                m = re.search(rf'"{key}"\s*:\s*([0-9.]+)', clean)
                if m:
                    data[key] = float(m.group(1))

        def _clamp(v: Any, default: float = 0.5) -> float:
            try:
                return max(0.0, min(1.0, float(v)))
            except (TypeError, ValueError):
                return default

        return EvaluationResult(
            relevance=_clamp(data.get("relevance")),
            accuracy=_clamp(data.get("accuracy")),
            completeness=_clamp(data.get("completeness")),
            clarity=_clamp(data.get("clarity")),
            issues=data.get("issues", []) if isinstance(data.get("issues"), list) else [],
            suggestions=data.get("suggestions", []) if isinstance(data.get("suggestions"), list) else [],
        )

    def _refine_answer(
        self,
        query: str,
        answer: str,
        evaluation: EvaluationResult,
    ) -> str:
        prompt = (
            f"Improve the following answer based on the feedback provided.\n\n"
            f"use the same query language\n"
            f"Question: {query}\n\n"
            f"Current answer:\n{answer}\n\n"
            f"Issues: {'; '.join(evaluation.issues) or 'none'}\n"
            f"Suggestions: {'; '.join(evaluation.suggestions) or 'none'}\n\n"
            f"Write an improved answer only (no preamble):"
        )
        try:
            refined = _call_llm(self.llm, prompt, retries=self.config.llm_retries)
            return refined if len(refined) > 10 else answer
        except LLMCallError:
            return answer

    @staticmethod
    def _adapt_query(original: str, suggestions: List[str]) -> str:
        """Append top suggestion keywords to broaden the retrieval query."""
        extra = " ".join(suggestions[:2])
        adapted = f"{original} {extra}".strip()
        logger.debug("  Query adapted: %r", adapted[:80])
        return adapted

    def get_stats(self) -> dict:
        """Returns runtime configuration as a stats dict."""
        return {
            "max_refinement_iterations":   self.config.max_refinement_iterations,
            "confidence_threshold":        self.config.confidence_threshold,
            "enable_answer_refinement":    self.config.enable_answer_refinement,
            "enable_retrieval_refinement": self.config.enable_retrieval_refinement,
            "llm_retries":                 self.config.llm_retries,
            "fast_mode":                   self.config.fast_mode,
        }

    # ── Async API ─────────────────────────────────────────────────────────

    async def aquery(self, query: str, context: Optional[Dict[str, Any]] = None) -> SelfRAGResult:
        """Async wrapper around :meth:`query`."""
        import asyncio
        return await asyncio.to_thread(self.query, query, context)

    async def __aenter__(self) -> "SelfIRAG":
        return self

    async def __aexit__(self, *_) -> bool:
        return False