from abc import ABC, abstractmethod
from typing import List, Tuple, Dict, Optional, Any
import logging
from .rag_config import RAGConfig
logger = logging.getLogger(__name__)




class BaseRAGSystem(ABC):
    """
    Unified base interface for all RAG systems
    """
    
    def __init__(self, config: Optional[RAGConfig] = None):
        """
        Initialize RAG system
        
        Args:
            config: System configuration
        """
        self.config = config or RAGConfig()
        self.config.validate()
        
        # إحصائيات النظام | System statistics
        self.stats = {
            'total_queries': 0,        # إجمالي الاستعلامات | Total queries
            'successful_queries': 0,   # الاستعلامات الناجحة | Successful queries
            'failed_queries': 0,       # الاستعلامات الفاشلة | Failed queries
            'total_documents': 0,      # إجمالي المستندات | Total documents
            'total_chunks': 0          # إجمالي القطع | Total chunks
        }
        
        logger.info(f"🚀 Initializing {self.__class__.__name__}")
    
    @abstractmethod
    def add_documents(self, docs: Dict[str, str]) -> Dict[str, int]:
        """
        Add documents to the system
        
        Args:
            docs:  Dictionary {doc_id: text}
        
        Returns:
            Dictionary {doc_id: num_chunks}
        """
        pass
    
    @abstractmethod
    def retrieve(self, query: str, top_k: Optional[int] = None) -> List[Tuple]:
        """
        Retrieve the nearest chunks to the query
        
        Args:
            query:  Query text
            top_k: Number of results
        
        Returns:
            List of (DocumentChunk, score)
        """
        pass
    
    @abstractmethod
    def generate(self, query: str, **kwargs) -> str:
        """
        Generate an answer for the query
        
        Args:
            query: Query text
            **kwargs: Additional parameters
        
        Returns:
            Answer text
        """
        pass
    
    def remove_document(self, doc_id: str) -> int:
        """
        Remove a document from the system
        
        Args:
            doc_id:  Document ID
        
        Returns:
            Number of deleted chunks
        """
        raise NotImplementedError(
            " ❌ This feature is not supported in this system"
        )
    
    def save(self, path: str) -> None:
        """
        Save the system
        
        Args:
            path:  Save path
        """
        raise NotImplementedError(
            "❌ This feature is not supported in this system"
        )
    
    @classmethod
    def load(cls, path: str, **kwargs):
        """
        Load a saved system
        
        Args:
            path:  Load path
            **kwargs: Additional parameters
        
        Returns:
            Loaded system
        """
        raise NotImplementedError(
            "❌ This feature is not supported in this system"
        )
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get system statistics
        
        Returns:
            Dictionary with statistics
        """
        return self.stats.copy()
    
    def reset_stats(self):
        """
        Reset statistics
        """
        self.stats = {
            'total_queries': 0,
            'successful_queries': 0,
            'failed_queries': 0,
            'total_documents': self.stats.get('total_documents', 0),
            'total_chunks': self.stats.get('total_chunks', 0)
        }
        logger.info("📊 Statistics reset")
    
    def validate_connection(self, test_query: str ) -> Dict:
        """
        Validate that the system is working correctly
        
        Args:
            test_query:  Test query
        
        Returns:
            dict: {
                "success": bool,
                "reason": str,
                "components": dict (if success)
            }
        """
        try:
            # التحقق من استرجاع القطع | Verify chunk retrieval
            chunks = self.retrieve(test_query, top_k=1)
            
            if not chunks:
                return {
                    "success": False,
                    "reason": "⚠️ No documents in the system",
                    "components": None
                }
            
            # التحقق من التوليد | Verify generation
            try:
                answer = self.generate(test_query)
                if answer:
                    return {
                        "success": True,
                        "reason": "✅ System working successfully",
                        "components": {
                            "retrieval": True,
                            "generation": True
                        }
                    }
            except Exception as gen_error:
                return {
                    "success": True,
                    "reason": "✅ Retrieval works, generation unavailable",
                    "components": {
                        "retrieval": True,
                        "generation": False,
                        "generation_error": str(gen_error)
                    }
                }
        
        except Exception as e:
            return {
                "success": False,
                "reason": f"❌Error: {str(e)}",
                "components": None
            }
    
    def cleanup(self):
        """
        Clean up resources
        """
        logger.info("🧹Cleaning up system resources")
    
    def __repr__(self) -> str:
        """
        String representation of the system
        """
        return (
            f"{self.__class__.__name__}("
            f"docs={self.stats['total_documents']}, "
            f"chunks={self.stats['total_chunks']}, "
            f"queries={self.stats['total_queries']})"
        )
    
    def __enter__(self):
        """Support for context manager"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """ Cleanup when exiting context"""
        self.cleanup()

    # ── Async API ────────────────────────────────────────────────────

    async def aadd_documents(self, docs: Dict[str, str]) -> Dict[str, int]:
        """
        Async add documents.
        Default: wraps sync add_documents in a thread.
        Override for native async implementations.
        """
        import asyncio
        return await asyncio.to_thread(self.add_documents, docs)

    async def aretrieve(self, query: str, top_k=None) -> List[Tuple]:
        """Async retrieve relevant chunks."""
        import asyncio
        return await asyncio.to_thread(self.retrieve, query, top_k)

    async def agenerate(self, query: str, **kwargs) -> str:
        """Async generate answer."""
        import asyncio
        return await asyncio.to_thread(self.generate, query, **kwargs)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
        return False