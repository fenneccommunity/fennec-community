from .stanze_ import StanzaTokenizer
from typing import List
import logging
from collections import Counter
import math
logger = logging.getLogger(__name__)

class BM25Scorer:
    """
    Best Match 25 (BM25) for Keyword Search
    Better than TF-IDF for short and medium texts
    """
    
    def __init__(self, k1: float = 1.5, b: float = 0.75, language: str = 'ar', 
                 use_lemmatization: bool = True):
        """
        Initialize BM25
        
        Args:
            k1: Term frequency saturation parameter (usually 1.2-2.0)
            b: Length normalization parameter (usually 0.75)
            language:  Language
            use_lemmatization:  Use lemmatization
        """
        self.k1 = k1
        self.b = b
        self.language = language
        self.idf = {}                    # معامل IDF لكل كلمة | IDF coefficient for each term
        self.avgdl = 0.0                 # متوسط طول المستند | Average document length
        self.doc_lengths = []            # أطوال المستندات | Document lengths
        self.corpus_size = 0             # عدد المستندات | Number of documents
        
        # إنشاء المحلل النصي
        # Create tokenizer
        self.tokenizer = StanzaTokenizer(language=language, use_lemmatization=use_lemmatization)
        
        logger.info(f"✅ BM25 initialized with Stanza tokenizer ({language})")

    def fit(self, documents: List[str]):
        """
        Train BM25 model
        
        Args:
            documents:  List of documents
        """
        logger.info(f"🔄 Training BM25 on {len(documents)} documents...")
        
        self.corpus_size = len(documents)
        
        # حساب أطوال المستندات
        # Calculate document lengths
        self.doc_lengths = [len(self.tokenizer.tokenize(doc)) for doc in documents]
        self.avgdl = sum(self.doc_lengths) / len(self.doc_lengths) if self.doc_lengths else 0
        
        # حساب IDF (Inverse Document Frequency)
        # Calculate IDF (Inverse Document Frequency)
        df = Counter()  # تكرار المستندات لكل كلمة | Document frequency for each term
        for doc in documents:
            terms = set(self.tokenizer.tokenize(doc))
            for term in terms:
                df[term] += 1
        
        # صيغة IDF: log((N - df + 0.5) / (df + 0.5) + 1)
        # IDF formula: log((N - df + 0.5) / (df + 0.5) + 1)
        for term, freq in df.items():
            self.idf[term] = math.log((self.corpus_size - freq + 0.5) / (freq + 0.5) + 1)
        
        logger.info(f"✅ BM25 training completed with {self.corpus_size} documents ")
        logger.info(f"📊 Vocabulary size: {len(self.idf)} terms ")
    
    def score(self, query: str, document: str, doc_idx: int) -> float:
        """
        Calculate BM25 score for a single document
        
        Args:
            query:     Query
            document:  Document
            doc_idx:   Document index
            
        Returns:
            BM25 score
        """
        query_terms = self.tokenizer.tokenize(query)
        doc_terms = self.tokenizer.tokenize(document)
        
        # حساب تكرار الكلمات في المستند
        # Calculate term frequency in document
        term_freq = Counter(doc_terms)
        
        score = 0.0
        doc_length = self.doc_lengths[doc_idx] if doc_idx < len(self.doc_lengths) else len(doc_terms)
        
        for term in query_terms:
            if term not in self.idf:
                continue
            
            tf = term_freq.get(term, 0)
            idf = self.idf[term]
            
            # صيغة BM25
            # BM25 formula
            numerator = tf * (self.k1 + 1)
            denominator = tf + self.k1 * (1 - self.b + self.b * (doc_length / self.avgdl))
            
            score += idf * (numerator / denominator)
        
        return score
    
    def batch_score(self, query: str, documents: List[str]) -> List[float]:
        """
        Calculate BM25 scores for a batch of documents
        
        Args:
            query:  Query
            documents: List of documents
            
        Returns:
            List of scores
        """
        return [self.score(query, doc, i) for i, doc in enumerate(documents)]

